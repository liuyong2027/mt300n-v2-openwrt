#!/usr/bin/env bash
set -euo pipefail
kit="$(cd "$(dirname "$0")/.." && pwd)"
cd "$kit"
mkdir -p reports
test ! -e openwrt
git init openwrt
git -C openwrt remote add origin https://github.com/openwrt/openwrt.git
git -C openwrt fetch --depth 1 origin f0a60eee2fe051741c643ea6118718aae1ef17fb
git -C openwrt checkout --detach FETCH_HEAD
cd openwrt
test "$(git rev-parse HEAD)" = f0a60eee2fe051741c643ea6118718aae1ef17fb
# The release includes exact feed commits. Do not replace them with moving branches.
cp feeds.conf.default "$kit/reports/feeds.conf.lock"
./scripts/feeds update -a
./scripts/feeds install -a
git init package/custom-xray
git -C package/custom-xray remote add origin https://github.com/yichya/luci-app-xray.git
git -C package/custom-xray fetch --depth 1 origin 521c5854d4433ce097e957c6b52f28423b0dc503
git -C package/custom-xray checkout --detach FETCH_HEAD
test "$(git -C package/custom-xray rev-parse HEAD)" = 521c5854d4433ce097e957c6b52f28423b0dc503
cp -R "$kit/package/luci-app-zerotier-mini" package/
cp -R "$kit/files" .
cp "$kit/config/mt300n-v2.config" .config
if [ "${INCLUDE_RULES:-false}" = true ]; then
    printf '\nCONFIG_PACKAGE_v2ray-geoip=y\nCONFIG_PACKAGE_v2ray-geosite=y\n' >> .config
fi
make defconfig
for pkg in luci xray-core luci-app-xray zerotier luci-app-zerotier-mini; do
    grep -qx "CONFIG_PACKAGE_${pkg}=y" .config || {
        echo "Required package was dropped by Kconfig: $pkg" >&2
        exit 1
    }
done
grep -qx 'CONFIG_TARGET_ramips_mt76x8_DEVICE_glinet_gl-mt300n-v2=y' .config
if [ "${INCLUDE_RULES:-false}" = true ]; then
    grep -qx 'CONFIG_PACKAGE_v2ray-geoip=y' .config
    grep -qx 'CONFIG_PACKAGE_v2ray-geosite=y' .config
fi
cp .config "$kit/reports/resolved.config"
./scripts/diffconfig.sh > "$kit/reports/diffconfig.txt"
git rev-parse HEAD > "$kit/reports/openwrt-commit.txt"
git -C package/custom-xray rev-parse HEAD > "$kit/reports/xray-ui-commit.txt"
find feeds -mindepth 1 -maxdepth 1 -type d | sort | while read -r feed; do
    printf '%s ' "$feed"
    git -C "$feed" rev-parse HEAD
done > "$kit/reports/feed-commits.txt"
