'use strict';
'require baseclass';

return baseclass.extend({
    parse: function(text) {
        text = String(text || '').trim();
        if (text.length > 49152) throw new Error('订阅超过 48 KiB，请使用仅含 VLESS 的订阅');
        if (!/^vless:\/\//m.test(text)) {
            try { text = atob(text.replace(/\s/g, '').replace(/-/g, '+').replace(/_/g, '/')); }
            catch (e) { throw new Error('不是 VLESS 链接列表或 Base64 订阅'); }
        }
        var nodes = [], skipped = 0, seen = {}, identityOf = this.identity, notices = [], isNotice = this.isNotice;
        text.split(/\r?\n/).forEach(function(line) {
            line = line.trim();
            if (!line) return;
            try {
                var u = new URL(line), q = u.searchParams;
                if (u.protocol !== 'vless:' || !['tcp','raw'].includes(q.get('type') || 'tcp') ||
                    q.get('security') !== 'reality' || q.get('flow') !== 'xtls-rprx-vision' ||
                    !['none',null,''].includes(q.get('encryption')) || u.password) throw new Error();
                var n = { address:u.hostname, port:u.port || '443', uuid:decodeURIComponent(u.username),
                    sni:q.get('sni') || q.get('serverName') || '', public_key:q.get('pbk') || q.get('password') || '',
                    short_id:q.get('sid') || '', fingerprint:q.get('fp') || 'chrome', spider_x:q.get('spx') || '/',
                    label:decodeURIComponent(u.hash.slice(1)) || u.hostname };
                if (isNotice(n.label)) { if (notices.indexOf(n.label)<0) notices.push(n.label); return; }
                if (!/^[a-zA-Z0-9][a-zA-Z0-9.-]{0,252}$/.test(n.address) ||
                    !/^[a-zA-Z0-9][a-zA-Z0-9.-]{0,252}$/.test(n.sni) ||
                    !/^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(n.uuid) ||
                    !/^[\w-]{43}$/.test(n.public_key) || !/^([0-9a-f]{2}){0,8}$/i.test(n.short_id) ||
                    !['chrome','firefox','safari','edge','ios'].includes(n.fingerprint) ||
                    !(Number(n.port) >= 1 && Number(n.port) <= 65535)) throw new Error();
                var identity = identityOf(n);
                if (!seen[identity]) { seen[identity] = n; nodes.push(n); }
                else if (/剩余|流量|到期|过期|有效期|traffic|expire/i.test(seen[identity].label) &&
                    !/剩余|流量|到期|过期|有效期|traffic|expire/i.test(n.label)) seen[identity].label = n.label;
            } catch (e) { skipped++; }
        });
        if (!nodes.length) throw new Error('没有可用的 VLESS / TCP(RAW) / REALITY / Vision 节点');
        if (nodes.length > 64) throw new Error('最多导入 64 个节点，请缩小订阅范围');
        return { nodes:nodes, skipped:skipped, notices:notices };
    },
    isNotice: function(label) { return /^(?:剩余流量|套餐到期|到期时间|有效期|traffic remaining|expires?)(?:\s|[:：])/i.test(String(label || '').trim()); },
    identity: function(n) {
        // All configurable connection parameters participate; labels do not.
        // Protocol/security/flow are fixed to VLESS/REALITY/Vision in this importer.
        return JSON.stringify([
            String(n.address || '').toLowerCase(), String(Number(n.port || 443)),
            String(n.uuid || '').toLowerCase(), String(n.sni || '').toLowerCase(),
            n.public_key || '', String(n.short_id || '').toLowerCase(),
            n.fingerprint || 'chrome', n.spider_x || '/'
        ]);
    }
});
