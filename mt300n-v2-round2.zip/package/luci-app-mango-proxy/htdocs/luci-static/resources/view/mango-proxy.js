'use strict';
'require view';
'require form';
'require uci';
'require rpc';
'require ui';
'require mango.subscription as subscription';

var pingNode = rpc.declare({object:'mango',method:'ping',params:['node'],expect:{}});
var getStatus = rpc.declare({object:'mango',method:'status',expect:{}});
var testSite = rpc.declare({object:'mango',method:'test',params:['site','route'],expect:{}});
var getSubscription = rpc.declare({object:'mango',method:'subscription',params:['url','route'],expect:{}});
var updateRules = rpc.declare({object:'mango',method:'update',params:['kind','route'],expect:{}});

return view.extend({
    load: function() { return uci.load('mango_proxy'); },
    tools: function(m) {
        var status = E('p', {}, '点击刷新查看服务状态和规则更新时间。');
        var notices=uci.get('mango_proxy','main','subscription_notices') || [];
        if (!Array.isArray(notices)) notices=[notices];
        var noticeBox=E('div',{},notices.map(function(text){return E('p',{},text);}));
        var noticeStatus=E('p',{},uci.get('mango_proxy','main','subscription_notice_status') || (notices.length ? '历史订阅提示：更新时间未知，请重新下载订阅核实。' : '暂无订阅提示'));
        var output = E('pre', {style:'white-space:pre-wrap'}, '尚未测试');
        var route = E('select', {'class':'cbi-input-select'}, [E('option',{value:'direct'},'路由器直连'),E('option',{value:'current'},'当前分流策略')]);
        var subURL = E('input',{type:'password',placeholder:'https://…',style:'width:100%',value:uci.get('mango_proxy','main','subscription_url') || '',autocomplete:'off'});
        var paste = E('textarea',{rows:3,style:'width:100%',placeholder:'也可粘贴 vless:// 链接或 Base64 订阅内容'});
        function button(label, action) {
            var b=E('button',{'class':'cbi-button cbi-button-action',type:'button'},label);
            b.addEventListener('click',function() {
                b.disabled=true;
                Promise.resolve().then(action).catch(function(e) {
                    ui.addNotification(null,E('p',{},e.message || '操作失败'), 'error');
                }).finally(function(){ b.disabled=false; });
            });
            return b;
        }
        function importNodes(text) {
            var parsed=subscription.parse(text), existing={};
            subscription.planImport(uci.sections('mango_proxy','node'),parsed.nodes);
            uci.sections('mango_proxy','node',function(n){existing[subscription.identity(n)]=n['.name'];});
            var added=0, updated=0, imported={};
            parsed.nodes.forEach(function(n) {
                var id=existing[subscription.identity(n)];
                if (!id) { id=uci.add('mango_proxy','node'); added++; } else updated++;
                imported[id]=true;
                Object.keys(n).forEach(function(k){uci.set('mango_proxy',id,k,n[k]);});
            });
            var noticeMessage=parsed.notices.length ? '提示更新于 '+new Date().toLocaleString() : '本次订阅没有流量或到期提示；下方如有旧提示，不代表当前状态。';
            uci.set('mango_proxy','main','subscription_notice_status',noticeMessage);
            noticeStatus.textContent=noticeMessage;
            if (parsed.notices.length) {
                uci.set('mango_proxy','main','subscription_notices',parsed.notices);
                noticeBox.textContent='';
                parsed.notices.forEach(function(text){noticeBox.appendChild(E('p',{},text));});
            }
            var selected=uci.get('mango_proxy','main','node');
            var backups=uci.get('mango_proxy','main','backup_nodes') || [];
            if (!Array.isArray(backups)) backups=String(backups).split(/\s+/);
            // Remove only old notice entries covered by this import and not in use.
            var identities={}; parsed.nodes.forEach(function(n){identities[subscription.identity(n)]=true;});
            uci.sections('mango_proxy','node',function(n){
                var id=n['.name'];
                if (subscription.isNotice(n.label) && identities[subscription.identity(n)] && !imported[id] && id!==selected && backups.indexOf(id)<0)
                    uci.remove('mango_proxy',id);
            });
            if (subURL.value) uci.set('mango_proxy','main','subscription_url',subURL.value);
            return uci.save().then(function(){
                ui.showModal('导入完成',[
                    E('p',{},'新增 '+added+'，更新 '+updated+'，跳过不支持的链接 '+parsed.skipped+'。订阅提示单独显示，保留其他已有节点。'),
                    E('p',{},'刷新页面后选择节点并保存应用。订阅地址仅保存在本路由器。'),
                    E('button',{'class':'cbi-button cbi-button-positive',click:function(){window.location.reload();}},'刷新页面')
                ]);
            });
        }
        function update(kind) {
            output.textContent='正在启动规则更新…';
            return updateRules(kind,route.value).then(function(r){
                if(r.exit_code!==0) throw new Error(r.message);
                var attempts=0;
                function poll() {
                    return new Promise(function(resolve){setTimeout(resolve,1000);}).then(getStatus).then(function(s){
                        output.textContent=s.update_status;
                        if(s.update_running && ++attempts<90) return poll();
                        if(s.update_running) output.textContent+='\n仍在更新，可稍后点击刷新状态。';
                    });
                }
                return poll();
            });
        }
        return E('div',{'class':'cbi-section'},[
            E('h3',{},'状态、订阅和规则'), status,

            button('刷新状态',function(){return getStatus().then(function(r){status.textContent='Xray：'+({running:'运行中',stopped:'已停止',inactive:'未运行','active with no instances':'未启动进程'}[r.service] || r.service)+'；启动状态：'+(r.phase || '暂无记录')+'；模式：'+({direct:'全部直连',global:'全局代理',split:'大陆分流',gfw:'GFW 分流'}[r.mode] || r.mode)+'；中国 IP：'+r.china+'；GFW 域名：'+r.gfw+'；当前节点：'+r.active_node+'；守护：'+r.failover+'；'+r.memory+'；存储 '+r.storage+'；规则更新：'+r.update_status;});}),
            E('p',{},'按已保存并应用的策略测试：直连模式直接访问，代理模式经过本机 Xray。结果不代表 Wi-Fi 客户端透明转发已验证。'),
            button('测试百度和 Google',function(){
                output.textContent='测试中…';
                return ['baidu','google'].reduce(function(p,site){return p.then(function(){
                    return testSite(site,'current').then(function(r){
                        if(output.textContent==='测试中…') output.textContent='';
                        if (r.message) { output.textContent+=({baidu:'百度',google:'谷歌'}[site] || site)+'：'+r.message+'\n'; return; }
                        var code=Number(String(r.result).split(' ')[0]);
                        output.textContent+=({baidu:'百度',google:'谷歌'}[site] || site)+'：'+(r.exit_code===0 && code>=200 && code<400 ? '可达' : '失败')+'（HTTP 状态 / 秒：'+r.result+'，错误码 '+r.exit_code+'）\n';
                    });
                });},Promise.resolve());
            }),output,
            E('h4',{},'VLESS 订阅／链接导入'),noticeStatus,noticeBox,
            E('p',{},'订阅／规则下载通道（仅影响下载）：'),route,subURL,paste,
            E('p',{},'支持 TCP/RAW + REALITY + Vision，保存节点总量最多 64 个、订阅最多 48 KiB。先保存当前表单再导入；导入后需选择节点并保存应用。'),
            button('下载订阅并导入',function(){
                if (!/^https:\/\//.test(subURL.value)) throw new Error('请输入 HTTPS 订阅地址');
                return m.save().then(function(){return getSubscription(subURL.value,route.value);}).then(function(r){
                    if(r.error) throw new Error(r.error); return importNodes(r.content);
                });
            }),
            button('导入粘贴内容',function(){return m.save().then(function(){return importNodes(paste.value);});}),
            E('h4',{},'规则更新'),
            E('p',{},'中国 IP 更新 CN/private GeoIP；GFWList 更新域名列表，不是 GFW IP 数据库。复杂路径/正则表达式暂不支持。更新需容纳新规则并保留 512 KiB 可写空间，成功后会重启代理。'),
            button('更新中国 IP',function(){return update('china');}),
            button('更新 GFW 域名',function(){return update('gfw');})
        ]);
    },
    render: function() {
        var m = new form.Map('mango_proxy', 'Xray 分流',
            '功能增强测试版。代理范围为 LAN 和获准的 ZeroTier 客户端；路由器自身流量直连。代理模式阻止这些客户端的公网 IPv6 与非 TCP/UDP 流量；内部网络始终直连。先填写节点再切换模式。');
        var s = m.section(form.NamedSection, 'main', 'policy', '代理模式');
        var o = s.option(form.ListValue, 'mode', '模式');
        o.value('direct', '全部直连');
        o.value('split', '分流代理：大陆直连，其余代理');
        o.value('global', '全局代理：公网 TCP/UDP 代理');
        o.value('gfw', 'GFW 列表：命中域名走代理，其余直连');
        o.rmempty = false;
        var modeOption = o;
        o = s.option(form.ListValue, 'node', '使用节点');
        o.value('', '请选择节点');
        uci.sections('mango_proxy', 'node', function(n) { o.value(n['.name'], n.label || n['.name']); });
        o.validate = function(id, value) {
            var mode = modeOption.formvalue(id);
            return mode === 'direct' || !!value || '代理模式必须选择节点';
        };
        o = s.option(form.Value, 'lan_device', '局域网设备');
        o.default = 'br-lan'; o.rmempty = false;
        o.validate = function(id, v) { return /^[a-zA-Z0-9_.-]{1,15}$/.test(v) || '请输入设备名，例如 br-lan'; };
        o = s.option(form.DynamicList, 'bypass4', '额外直连 IPv4 网段', '可填写 ZeroTier 使用的公网地址网段；私有网段和实际 zt 接口路由会自动保留直连。');
        o.datatype = 'ip4addr';
        o = s.option(form.DynamicList, 'direct_domains', '域名白名单（强制直连）', '例如 example.com，包含其子域名。不填写 https://、端口或路径。优先于所有代理模式。');
        o.validate = function(id,v){return !v || (/^[a-zA-Z0-9][a-zA-Z0-9.-]*\.[a-zA-Z]{2,}$/.test(v) && v.indexOf('..')<0) || '请输入域名，例如 example.com';};
        o = s.option(form.Flag, 'zt_gateway', '允许 ZeroTier 客户端借本机上网');
        o.rmempty = false;
        o = s.option(form.DynamicList, 'zt_sources', '获准的 ZeroTier IPv4 地址／网段', '必须显式填写，留空则不允许。还需在 ZeroTier Central 设置经本机的默认路由，并在客户端允许默认路由。');
        o.datatype = 'ip4addr'; o.depends('zt_gateway', '1');
        o = s.option(form.Flag, 'failover', '自动守护与节点切换', '每 60 秒经当前节点探测 Google／Cloudflare；两个地址均失败、连续 3 轮后切换备用节点。短暂故障不切换；无备用节点时重启当前节点。持续故障时逐步延长检查间隔至 300 秒，恢复后回到 60 秒。默认关闭。');
        o.rmempty = false;
        o = s.option(form.MultiValue, 'backup_nodes', '备用节点', '依次循环尝试；不会修改你选择的主节点。修改配置并应用后回到主节点。');
        uci.sections('mango_proxy','node',function(n){o.value(n['.name'],n.label || n['.name']);});
        // LuCI MultiValue passes null choices to Dropdown when no nodes exist.
        o.transformChoices = function() {
            var choices = {};
            (this.keylist || []).forEach(function(key, i) { choices[key] = this.vallist[i]; }, this);
            return choices;
        };
        o.depends('failover','1');
        s = m.section(form.GridSection, 'node', 'VLESS / RAW / REALITY / Vision 节点');
        s.anonymous = true; s.addremove = true;
        s.description = '手动检查服务器 TCP 端口，不自动测试。域名经直连 DNS（223.5.5.5，失败后尝试 119.29.29.29）解析。端口可连接不代表 VLESS 认证成功。请先保存节点修改。';
        o = s.option(form.DummyValue, '_index', '序号');
        o.cfgvalue = function(id) {
            var ids = this.section.cfgsections();
            var index = ids.indexOf(id);
            return index >= 0 ? String(index + 1) : '—';
        };
        o = s.option(form.DummyValue, '_type', '类型'); o.default = 'VLESS';
        o = s.option(form.Value, 'label', '名称'); o.rmempty = false;
        o = s.option(form.Value, 'address', '服务器 IPv4 或域名'); o.rmempty = false;
        o.validate = function(id, v) { return /^[a-zA-Z0-9][a-zA-Z0-9.-]*$/.test(v || '') || '请输入 IPv4 地址或域名'; };
        o = s.option(form.Value, 'port', '端口'); o.datatype = 'port'; o.default = '443'; o.rmempty = false;
        o = s.option(form.DummyValue, '_role', '自动切换');
        o.cfgvalue = function(id) {
            var backup = uci.get('mango_proxy','main','backup_nodes') || [];
            if (!Array.isArray(backup)) backup = String(backup).split(/\s+/);
            if (uci.get('mango_proxy','main','node') === id) return '主节点';
            return backup.indexOf(id) >= 0 ? '备用' : '未选';
        };
        o = s.option(form.DummyValue, '_ping', '服务器端口检查');
        o.editable = true; // GridSection must render the widget instead of its empty text value.
        var pingQueue = Promise.resolve(), pingStates = {};
        o.renderWidget = function(id) {
            var state = pingStates[id] || (pingStates[id] = {busy:false,text:'未测试',views:[]});
            var result = E('span', {}, state.text);
            var b = E('button', {type:'button','class':'cbi-button'}, '检查');
            state.views.push({result:result,button:b});
            function refresh() {
                state.views.forEach(function(v) { v.result.textContent=state.text; v.button.disabled=state.busy; });
            }
            function run() {
                if (state.busy) return;
                state.busy=true; state.text='排队中…'; refresh();
                pingQueue=pingQueue.then(async function() {
                    state.text='测试中…'; refresh();
                    try {
                        var r=await pingNode(id);
                        state.text=r.result || '无结果';
                    } catch(e) { state.text='测试失败，请确认节点已保存、后端已更新'; }
                }).catch(function() { state.text='测试失败'; }).finally(function() {
                    state.busy=false; refresh();
                });
            }
            b.addEventListener('click',run);
            refresh();
            return E('div', {}, [result, ' ', b]);
        };
        o = s.option(form.Value, 'uuid', 'UUID'); o.password = true; o.rmempty = false; o.modalonly = true;
        o = s.option(form.Value, 'sni', 'SNI'); o.rmempty = false; o.modalonly = true;
        o = s.option(form.Value, 'public_key', 'REALITY 公钥'); o.password = true; o.rmempty = false; o.modalonly = true;
        o = s.option(form.Value, 'short_id', '短标识（Short ID）'); o.rmempty = true; o.modalonly = true;
        o = s.option(form.ListValue, 'fingerprint', '客户端指纹'); o.modalonly = true;
        ['chrome', 'firefox', 'safari', 'edge', 'ios'].forEach(function(v) { o.value(v); });
        o.default = 'chrome'; o.rmempty = false;
        o = s.option(form.Value, 'spider_x', '探测路径（SpiderX）'); o.placeholder = '/'; o.modalonly = true;
        var tools = this.tools(m);
        return m.render().then(function(content) { return E('div',{},[tools,content]); });
    }
});
