'use strict';
'require view';
'require form';
'require uci';

return view.extend({
    load: function() { return uci.load('mango_proxy'); },
    render: function() {
        var m = new form.Map('mango_proxy', 'Xray 分流',
            '第二轮测试版。代理范围为 LAN 和获准的 ZeroTier 客户端；路由器自身流量直连。代理模式阻止这些客户端的公网 IPv6 与非 TCP/UDP 流量；内部网络始终直连。先填写节点再切换模式。');
        var s = m.section(form.NamedSection, 'main', 'policy', '代理模式');
        var o = s.option(form.ListValue, 'mode', '模式');
        o.value('direct', '全部直连');
        o.value('split', '分流代理：大陆直连，其余代理');
        o.value('global', '全局代理：公网 TCP/UDP 代理');
        o.rmempty = false;
        o = s.option(form.ListValue, 'node', '使用节点');
        o.value('', '请选择节点');
        uci.sections('mango_proxy', 'node', function(n) { o.value(n['.name'], n.label || n['.name']); });
        o.validate = function(id, value) {
            var mode = s.children.filter(function(c) { return c.option === 'mode'; })[0].formvalue(id);
            return mode === 'direct' || !!value || '代理模式必须选择节点';
        };
        o = s.option(form.Value, 'lan_device', 'LAN 设备');
        o.default = 'br-lan'; o.rmempty = false;
        o.validate = function(id, v) { return /^[a-zA-Z0-9_.-]{1,15}$/.test(v) || '请输入设备名，例如 br-lan'; };
        o = s.option(form.DynamicList, 'bypass4', '额外直连 IPv4 网段', '可填写 ZeroTier 使用的公网地址网段；私有网段和实际 zt 接口路由会自动保留直连。');
        o.datatype = 'ip4addr';
        o = s.option(form.Flag, 'zt_gateway', '允许 ZeroTier 客户端借本机上网');
        o.rmempty = false;
        o = s.option(form.DynamicList, 'zt_sources', '获准的 ZeroTier IPv4 地址／网段', '必须显式填写，留空则不允许。还需在 ZeroTier Central 设置经本机的默认路由，并在客户端允许默认路由。');
        o.datatype = 'ip4addr'; o.depends('zt_gateway', '1');
        s = m.section(form.GridSection, 'node', 'VLESS / RAW / REALITY / Vision 节点');
        s.anonymous = true; s.addremove = true;
        o = s.option(form.Value, 'label', '名称'); o.rmempty = false;
        o = s.option(form.Value, 'address', '服务器 IPv4 或域名'); o.rmempty = false;
        o.validate = function(id, v) { return /^[a-zA-Z0-9][a-zA-Z0-9.-]*$/.test(v || '') || '请输入 IPv4 地址或域名'; };
        o = s.option(form.Value, 'port', '端口'); o.datatype = 'port'; o.default = '443'; o.rmempty = false;
        o = s.option(form.Value, 'uuid', 'UUID'); o.password = true; o.rmempty = false;
        o = s.option(form.Value, 'sni', 'SNI'); o.rmempty = false;
        o = s.option(form.Value, 'public_key', 'REALITY 公钥 / Password'); o.password = true; o.rmempty = false;
        o = s.option(form.Value, 'short_id', 'Short ID'); o.rmempty = true;
        o = s.option(form.ListValue, 'fingerprint', 'Fingerprint');
        ['chrome', 'firefox', 'safari', 'edge'].forEach(function(v) { o.value(v); });
        o.default = 'chrome'; o.rmempty = false;
        o = s.option(form.Value, 'spider_x', 'SpiderX'); o.placeholder = '/';
        return m.render();
    }
});
