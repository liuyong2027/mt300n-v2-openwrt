-- MIT. Pure policy model: shared by the router and host-side tests.
local M = {}
local private = {'0.0.0.0/8','10.0.0.0/8','100.64.0.0/10','127.0.0.0/8',
    '169.254.0.0/16','172.16.0.0/12','192.168.0.0/16','224.0.0.0/3'}
local function list(v)
    if type(v) == 'table' then return v end
    if v and v ~= '' then return {v} end
    return {}
end
function M.ip4(v)
    if type(v) ~= 'string' then return false end
    local ip, prefix = v:match('^([%d%.]+)/(%d+)$')
    if not ip then ip = v end
    local a,b,c,d = ip:match('^(%d+)%.(%d+)%.(%d+)%.(%d+)$')
    if not a then return false end
    for _, n in ipairs({a,b,c,d}) do
        if #n > 3 or tonumber(n) > 255 or (#n > 1 and n:sub(1,1) == '0') then return false end
    end
    return not prefix or tonumber(prefix) <= 32
end
local function host(v)
    return type(v) == 'string' and #v > 0 and #v <= 253 and v:match('^[%w][%w%.%-]*$') ~= nil
end
local function checked_ips(v)
    local r = {}
    for _, ip in ipairs(list(v)) do assert(M.ip4(ip), 'Invalid IPv4/CIDR'); r[#r+1] = ip end
    return r
end
function M.policy(p)
    assert(p.mode == 'direct' or p.mode == 'split' or p.mode == 'global' or p.mode == 'gfw', 'Invalid mode')
    local lan = p.lan_device or 'br-lan'
    assert(#lan <= 15 and lan:match('^[%w_.%-]+$'), 'Invalid LAN device')
    local bypass = {}
    for _, ip in ipairs(private) do bypass[#bypass+1] = ip end
    for _, ip in ipairs(checked_ips(p.bypass4)) do bypass[#bypass+1] = ip end
    for _, ip in ipairs(checked_ips(p.zt_routes)) do bypass[#bypass+1] = ip end
    return {mode=p.mode, lan=lan, bypass=bypass,
        sources=p.zt_gateway == '1' and checked_ips(p.zt_sources) or {}}
end
function M.node(n)
    assert(n, 'Select a node before enabling proxy')
    assert(host(n.address) and host(n.sni), 'Invalid server or SNI')
    local port = tonumber(n.port)
    assert(port and port >= 1 and port <= 65535 and port == math.floor(port), 'Invalid port')
    assert(type(n.uuid) == 'string' and #n.uuid == 36 and
        n.uuid:match('^%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x$'), 'Invalid UUID')
    assert(type(n.public_key) == 'string' and #n.public_key == 43 and n.public_key:match('^[%w_%-]+$'), 'Invalid REALITY key')
    local sid = n.short_id or ''
    assert(#sid <= 16 and #sid % 2 == 0 and (sid == '' or sid:match('^%x+$')), 'Invalid Short ID')
    local fp = n.fingerprint or 'chrome'
    assert(({chrome=true,firefox=true,safari=true,edge=true})[fp], 'Invalid fingerprint')
    return {tag='proxy',protocol='vless',settings={vnext={{address=n.address,port=port,
        users={{id=n.uuid,encryption='none',flow='xtls-rprx-vision'}}}}},
        streamSettings={network='raw',security='reality',
            realitySettings={serverName=n.sni,publicKey=n.public_key,shortId=sid,
                fingerprint=fp,spiderX=n.spider_x or '/'}}}
end
function M.xray(p, n)
    local q = M.policy(p)
    local out = {{tag='direct',protocol='freedom',settings={domainStrategy='UseIPv4'}},
        {tag='block',protocol='blackhole'}, {tag='dns-out',protocol='dns'}}
    if q.mode ~= 'direct' then out[#out+1] = M.node(n) end
    local dest = (q.mode == 'direct' or q.mode == 'gfw') and 'direct' or 'proxy'
    local rules = {
        {type='field',inboundTag={'dns-in'},outboundTag='dns-out'},
        {type='field',inboundTag={'dns-query'},ip={'223.5.5.5'},port='53',outboundTag='direct'},
        {type='field',inboundTag={'dns-query'},outboundTag=dest},
        {type='field',ip=q.bypass,outboundTag='direct'}
    }
    -- Separate loopback-only probe port tests the node, independent of split rules.
    rules[#rules+1]={type='field',inboundTag={'proxy-health'},outboundTag=q.mode=='direct' and 'direct' or 'proxy'}
    local dns = {}
    if q.mode ~= 'direct' then
        dns[#dns+1] = {address='223.5.5.5',domains={'full:' .. n.address},skipFallback=true}
    end
    local whitelist={}
    for _,domain in ipairs(list(p.direct_domains)) do
        assert(host(domain) and domain:find('.',1,true) and not domain:find('..',1,true), 'Invalid direct domain')
        whitelist[#whitelist+1]='domain:'..domain:lower()
    end
    if #whitelist > 0 then
        rules[#rules+1]={type='field',domain=whitelist,outboundTag='direct'}
        dns[#dns+1]={address='223.5.5.5',domains=whitelist,skipFallback=true}
    end
    if q.mode == 'split' then
        dns[#dns+1] = {address='223.5.5.5',domains={'geosite:cn'},skipFallback=true}
        rules[#rules+1] = {type='field',domain={'geosite:cn'},outboundTag='direct'}
        rules[#rules+1] = {type='field',ip={'geoip:cn'},outboundTag='direct'}
    end
    if q.mode == 'gfw' then
        assert(p.gfw_proxy and #p.gfw_proxy > 0, 'GFW rules missing; update rules first')
        if p.gfw_direct and #p.gfw_direct > 0 then
            rules[#rules+1]={type='field',domain=p.gfw_direct,outboundTag='direct'}
            dns[#dns+1]={address='223.5.5.5',domains=p.gfw_direct,skipFallback=true}
        end
        rules[#rules+1]={type='field',domain=p.gfw_proxy,outboundTag='proxy'}
        dns[#dns+1]={address='1.1.1.1',domains=p.gfw_proxy,skipFallback=true}
        -- GFW DNS queries use the proxy; unmatched domains still use domestic DNS.
        rules[3].outboundTag='proxy'
    end
    dns[#dns+1] = (q.mode == 'direct' or q.mode == 'gfw') and '223.5.5.5' or '1.1.1.1'
    rules[#rules+1] = {type='field',network='tcp,udp',outboundTag=dest}
    return {log={loglevel='warning'},
        inbounds={{tag='proxy-health',listen='127.0.0.1',port=10809,protocol='socks',settings={auth='noauth',udp=false}},
            {tag='local-test',listen='127.0.0.1',port=10808,protocol='socks',settings={auth='noauth',udp=false}},
            {tag='transparent',listen='0.0.0.0',port=12345,protocol='dokodemo-door',
            settings={network='tcp,udp',followRedirect=true},
            streamSettings={sockopt={tproxy='tproxy'}},
            sniffing={enabled=true,destOverride={'http','tls','quic'},routeOnly=true}},
            {tag='dns-in',listen='127.0.0.1',port=1053,protocol='dokodemo-door',
                settings={address='1.1.1.1',port=53,network='tcp,udp'}}},
        outbounds=out,
        dns={tag='dns-query',queryStrategy='UseIPv4',disableFallbackIfMatch=true,servers=dns},
        routing={domainStrategy='IPIfNonMatch',rules=rules}}
end
local function quote(v)
    return '"' .. v:gsub('[%z\1-\31\\"]',function(c)
        if c == '\\' then return '\\\\' end
        if c == '"' then return '\\"' end
        return string.format('\\u%04x',string.byte(c))
    end) .. '"'
end
function M.json(v)
    if type(v) == 'string' then return quote(v) end
    if type(v) == 'boolean' or type(v) == 'number' then return tostring(v) end
    assert(type(v) == 'table', 'Unsupported JSON type')
    local r = {}
    if #v > 0 then
        for _, x in ipairs(v) do r[#r+1] = M.json(x) end
        return '[' .. table.concat(r,',') .. ']'
    end
    for k,x in pairs(v) do r[#r+1] = quote(k) .. ':' .. M.json(x) end
    table.sort(r)
    return '{' .. table.concat(r,',') .. '}'
end
function M.nft(p)
    local q = M.policy(p)
    local active = q.mode ~= 'direct'
    local allowed = #q.sources > 0
    local lines = {'add table inet mango_proxy', 'flush table inet mango_proxy',
        'table inet mango_proxy {',
        'set bypass4 { type ipv4_addr; flags interval; auto-merge; elements = { ' .. table.concat(q.bypass,', ') .. ' } }'}
    local function add(s) lines[#lines+1] = s end
    if allowed then add('set zt_sources { type ipv4_addr; flags interval; auto-merge; elements = { ' .. table.concat(q.sources,', ') .. ' } }') end
    add('chain guard { type filter hook forward priority -10; policy accept;')
    -- Always deny unauthorized ZeroTier use as a routed gateway, including IPv6.
    add('iifname "zt*" jump zt_guard')
    if active then
        add('iifname "' .. q.lan .. '" jump fail_closed')
        if allowed then add('iifname "zt*" ip saddr @zt_sources jump fail_closed') end
    end
    add('}')
    add('chain zt_guard {')
    add('ct state established,related ct direction reply return')
    if allowed then add('ip saddr @zt_sources return') end
    add('drop\n}')
    add('chain fail_closed {')
    add('ip daddr @bypass4 return')
    add('ip6 daddr { fc00::/7, fe80::/10, ff00::/8 } return')
    add('oifname "zt*" return')
    -- Captured traffic is locally delivered, never forwarded. Anything left must not leak.
    add('drop\n}')
    if active then
        add('chain capture {')
        add('fib daddr type local return')
        add('fib daddr oifname "zt*" return')
        add('ip daddr @bypass4 return')
        add('meta nfproto ipv4 meta l4proto { tcp, udp } meta mark set 0x100 tproxy ip to 127.0.0.1:12345 accept')
        add('}')
        add('chain prerouting { type filter hook prerouting priority -160; policy accept;')
        add('ct direction reply return')
        -- Port 53 goes to router dnsmasq via the later DNAT hook, never to tproxy.
        add('meta l4proto { tcp, udp } th dport 53 return')
        add('iifname "' .. q.lan .. '" jump capture')
        if allowed then add('iifname "zt*" ip saddr @zt_sources jump capture') end
        add('}')
        add('chain dns_capture { type nat hook prerouting priority -105; policy accept;')
        add('iifname "' .. q.lan .. '" meta nfproto ipv4 meta l4proto { tcp, udp } th dport 53 redirect to :53')
        if allowed then add('iifname "zt*" ip saddr @zt_sources meta l4proto { tcp, udp } th dport 53 redirect to :53') end
        add('}')
    end
    add('}')
    return table.concat(lines,'\n') .. '\n'
end
return M
