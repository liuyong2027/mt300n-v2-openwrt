local M={}
local function valid(d)
    if type(d)~='string' or #d==0 or #d>253 or d:find('[^a-z0-9.-]') or d:find('..',1,true) then return false end
    for label in d:gmatch('[^.]+') do
        if #label>63 or label:sub(1,1)=='-' or label:sub(-1)=='-' then return false end
    end
    return d:sub(1,1)~='.' and d:sub(-1)~='.'
end
local function covered(d,set)
    while d do
        if set[d] then return true end
        d=d:match('^[^.]+%.(.+)$')
    end
    return false
end
function M.render(mode,cn,gfw,whitelist)
    local direct,proxy={},{}
    if mode=='direct' then return '' end
    if type(whitelist)=='string' then whitelist={whitelist} end
    for _,d in ipairs(whitelist or {}) do d=d:lower(); assert(valid(d),'Invalid DNS whitelist'); direct[d]=true end
    if mode=='split' then
        for _,d in ipairs(cn or {}) do assert(valid(d),'Invalid CN DNS rule'); direct[d]=true end
    elseif mode=='gfw' then
        for _,line in ipairs(gfw or {}) do
            local mark,d=line:sub(1,1),line:sub(2)
            assert((mark=='+' or mark=='-') and valid(d),'Invalid GFW DNS rule')
            if mark=='-' then direct[d]=true else proxy[d]=true end
        end
    end
    local rows={}
    for d in pairs(direct) do rows[#rows+1]='server=/'..d..'/223.5.5.5'; rows[#rows+1]='server=/'..d..'/119.29.29.29' end
    for d in pairs(proxy) do
        -- Whitelist priority applies to all descendants, even a more specific GFW entry.
        if not covered(d,direct) then rows[#rows+1]='server=/'..d..'/127.0.0.1#1053' end
    end
    table.sort(rows)
    return #rows>0 and table.concat(rows,'\n')..'\n' or ''
end
return M
