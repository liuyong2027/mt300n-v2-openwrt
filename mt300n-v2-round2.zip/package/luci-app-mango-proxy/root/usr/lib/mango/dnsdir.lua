local M={}
function M.get(uci)
    local id,dir
    uci:foreach('dhcp','dnsmasq',function(s)
        if not id then id=s['.name']; dir=s.confdir end
    end)
    assert(id and id:match('^[a-zA-Z0-9_]+$'),'Missing or invalid dnsmasq instance')
    dir=dir or ('/tmp/dnsmasq.'..id..'.d')
    -- Do not silently install a file excluded by custom conf-dir suffix filters.
    assert(dir:match('^/[a-zA-Z0-9_./-]+$') and not dir:find('..',1,true),'Unsupported dnsmasq confdir')
    return dir,id
end
return M
