-- MIT. Extract CN IPv4 CIDRs from a v2fly GeoIP protobuf. No network and no code execution.
local M = {}
local function varint(data, i)
    local n, shift = 0, 0
    while i <= #data and shift <= 28 do
        local b = data:byte(i)
        i = i + 1
        n = n + (b % 128) * (2 ^ shift)
        if b < 128 then return n, i end
        shift = shift + 7
    end
    return nil, i
end
local function fields(data)
    local i, out = 1, {}
    while i <= #data do
        local tag
        tag, i = varint(data, i)
        if not tag then return nil end
        local field, wire = math.floor(tag / 8), tag % 8
        local value
        if wire == 2 then
            local size
            size, i = varint(data, i)
            if not size or i + size - 1 > #data then return nil end
            value = data:sub(i, i + size - 1)
            i = i + size
        elseif wire == 0 then
            value, i = varint(data, i)
            if not value then return nil end
        else
            return nil
        end
        out[#out+1] = {field, wire, value}
    end
    return out
end
function M.cidrs(data)
    local top = fields(data)
    if not top then return nil end
    local result = {}
    for _, item in ipairs(top) do
        if item[1] == 1 and item[2] == 2 then
            local body = fields(item[3])
            if not body then return nil end
            local code
            for _, field in ipairs(body) do
                if field[1] == 1 and field[2] == 2 then code = field[3] end
            end
            if code == 'cn' then
                for _, field in ipairs(body) do
                    if field[1] == 2 and field[2] == 2 then
                        local cidr = fields(field[3])
                        if cidr then
                            local ip, prefix
                            for _, part in ipairs(cidr) do
                                if part[1] == 1 and part[2] == 2 then ip = part[3] end
                                if part[1] == 2 and part[2] == 0 then prefix = part[3] end
                            end
                            if ip and #ip == 4 and prefix and prefix >= 1 and prefix <= 32 then
                                local a, b, c, d = ip:byte(1, 4)
                                result[#result+1] = string.format('%d.%d.%d.%d/%d', a, b, c, d, prefix)
                            end
                        end
                    end
                end
            end
        end
    end
    return result
end
function M.read(...)
    for i = 1, select('#', ...) do
        local file = io.open(select(i, ...), 'r')
        if file then
            local list = {}
            for line in file:lines() do
                if line ~= '' then list[#list+1] = line end
            end
            file:close()
            return list
        end
    end
    return {}
end
function M.write_file(data, path)
    local list = M.cidrs(data)
    if not list then return nil end
    local file = assert(io.open(path, 'w'))
    if #list > 0 then assert(file:write(table.concat(list, '\n'), '\n')) end
    assert(file:close())
    return #list
end
if arg and arg[0] and arg[0]:match('geoip%.lua$') and arg[1] and arg[2] then
    local file = assert(io.open(arg[1], 'rb'))
    local data = file:read('*a')
    file:close()
    local count = assert(M.write_file(data, arg[2]))
    io.stderr:write('CN CIDRs: ', count, '\n')
end
return M
