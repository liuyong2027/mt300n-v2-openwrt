local M={}
function M.candidates(p, exists)
    local result,seen={},{}
    local function add(id)
        if type(id)=='string' and id:match('^[%w_]+$') and not seen[id] and exists(id) then
            seen[id]=true; result[#result+1]=id
        end
    end
    add(p.node)
    local backup=p.backup_nodes or {}
    if type(backup)=='string' then local parsed={}; for id in backup:gmatch('%S+') do parsed[#parsed+1]=id end; backup=parsed end
    for _,id in ipairs(backup) do add(id) end
    return result
end
function M.active(p, runtime, exists)
    local ids=M.candidates(p,exists)
    if p.failover=='1' then for _,id in ipairs(ids) do if id==runtime then return id end end end
    return p.node
end
function M.next(ids,current)
    if #ids<2 then return nil end
    for i,id in ipairs(ids) do if id==current then return ids[i % #ids + 1] end end
    return ids[1]
end
return M
