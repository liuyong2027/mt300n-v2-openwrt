-- Convert domain-only AutoProxy rules. Never execute downloaded expressions.
local M = {}
function M.convert(text)
    assert(#text <= 512*1024 and text:find('[AutoProxy',1,true), 'Invalid GFWList')
    local proxy, direct, skipped = {}, {}, 0
    for line in text:gmatch('[^\r\n]+') do
        line=line:match('^%s*(.-)%s*$')
        if line ~= '' and line:sub(1,1) ~= '!' and line:sub(1,1) ~= '[' then
            local except = line:sub(1,2) == '@@'
            if except then line=line:sub(3) end
            line=line:gsub('^||',''):gsub('^|',''):gsub('^https?://',''):gsub('^%.','')
            line=line:gsub('[%^|]$',''):gsub('/$',''):lower()
            -- Path, wildcard, regexp and filter-option expressions are not broadened.
            if #line <= 253 and line:match('^[a-z0-9][a-z0-9%.%-]*%.[a-z][a-z]+$') then
                if except then direct[line]=true else proxy[line]=true end
            else skipped=skipped+1 end
        end
    end
    local output, count = {}, 0
    for d in pairs(direct) do output[#output+1]='-'..d end
    for d in pairs(proxy) do
        if not direct[d] then output[#output+1]='+'..d; count=count+1 end
    end
    assert(count >= 100 and count <= 20000, 'Unexpected GFW domain count')
    table.sort(output)
    return table.concat(output,'\n')..'\n', count, skipped
end
function M.load(path)
    local p, d = {}, {}
    local f=io.open(path,'r')
    if not f then return p,d end
    for line in f:lines() do
        local flag,host=line:match('^([+-])([a-z0-9%.%-]+)$')
        if host then
            local target=flag=='+' and p or d
            target[#target+1]='domain:'..host
        end
    end
    f:close()
    return p,d
end
return M
