/* MIT: measure only TCP connect, without TLS or node authentication. */
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static double now_ms(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) return -1;
    return t.tv_sec * 1000.0 + t.tv_nsec / 1000000.0;
}
int main(int argc, char **argv) {
    struct sockaddr_in target = {.sin_family = AF_INET};
    char *end;
    long port;
    int fd, rc, error = 0;
    socklen_t len = sizeof(error);
    double start, elapsed;
    if (argc != 3 || inet_pton(AF_INET, argv[1], &target.sin_addr) != 1) return 2;
    port = strtol(argv[2], &end, 10);
    if (!*argv[2] || *end || port < 1 || port > 65535) return 2;
    target.sin_port = htons((unsigned short)port);
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return 1;
    if (fcntl(fd, F_SETFL, O_NONBLOCK) < 0) { close(fd); return 1; }
    start = now_ms();
    if (start < 0) { close(fd); return 1; }
    rc = connect(fd, (struct sockaddr *)&target, sizeof(target));
    if (rc && errno == EINPROGRESS) {
        struct pollfd event = {.fd = fd, .events = POLLOUT};
        do {
            int remaining = (int)(3000 - (now_ms() - start));
            if (remaining <= 0) { close(fd); return 28; }
            rc = poll(&event, 1, remaining);
        } while (rc < 0 && errno == EINTR);
        if (rc == 0) { close(fd); return 28; }
        if (rc < 0 || getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &len) || error) {
            close(fd); return 1;
        }
    } else if (rc) { close(fd); return 1; }
    elapsed = now_ms() - start;
    close(fd);
    printf("%.1f\n", elapsed);
    return 0;
}
