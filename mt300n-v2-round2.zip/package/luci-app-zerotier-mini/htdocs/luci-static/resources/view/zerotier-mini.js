'use strict';
'require view';
'require form';

return view.extend({
    render: function() {
        var m = new form.Map('zerotier', 'ZeroTier',
            '加入网络后需在 ZeroTier Central 授权。此页配置客户端；网关转发、DNS 和防火墙需另行配置。');
        var s = m.section(form.NamedSection, 'global', 'zerotier', '全局设置');
        var o = s.option(form.Flag, 'enabled', '启用 ZeroTier');
        o.rmempty = false;
        o = s.option(form.Value, 'port', '监听端口');
        o.datatype = 'port';
        o.placeholder = '9993';
        s = m.section(form.GridSection, 'network', '网络');
        s.addremove = true;
        s.anonymous = true;
        o = s.option(form.Value, 'id', '网络 ID');
        o.rmempty = false;
        o.validate = function(section_id, value) {
            return /^[0-9a-fA-F]{16}$/.test(value || '') || '请输入 16 位十六进制 网络 ID';
        };
        o = s.option(form.Flag, 'allow_managed', '接受托管地址和私有路由');
        o.default = '1';
        o.rmempty = false;
        o = s.option(form.Flag, 'allow_global', '接受公网地址和路由');
        o.default = '0';
        o.rmempty = false;
        o = s.option(form.Flag, 'allow_default', '接受远端默认路由',
            '作为出口网关的本机一般保持关闭，避免把本机出口指回 ZeroTier。');
        o.default = '0';
        o.rmempty = false;
        o = s.option(form.Flag, 'allow_dns', '接受 DNS 设置');
        o.default = '0';
        o.rmempty = false;
        return m.render();
    }
});
