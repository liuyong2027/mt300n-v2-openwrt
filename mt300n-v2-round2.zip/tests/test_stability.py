import hashlib
import os
from pathlib import Path
import signal
import socket
import subprocess
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
HELPERS = ROOT / 'package/luci-app-mango-proxy/root/usr/libexec'


@unittest.skipIf(os.name == 'nt', 'Linux shell/socket integration tests run in CI')
class StabilityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.bin = self.base / 'bin'
        self.bin.mkdir()
        self.env = {**os.environ, 'PATH': str(self.bin) + ':' + os.environ['PATH']}

    def script(self, name, text):
        path = self.bin / name
        path.write_text('#!/bin/sh\n' + text)
        path.chmod(0o755)
        return str(path)

    def run_script(self, path, *args, **kwargs):
        return subprocess.run(['sh', str(path), *args], env=self.env, text=True,
                              capture_output=True, timeout=12, **kwargs)

    def test_tcp_connect_finishes_without_tls(self):
        exe = self.base / 'tcpcheck'
        subprocess.run(['cc', '-Wall', '-Wextra', '-Werror', '-o', str(exe),
                        str(ROOT / 'package/mango-tcpcheck/src/tcpcheck.c')], check=True)
        with socket.socket() as listener:
            listener.bind(('127.0.0.1', 0))
            listener.listen()
            start = time.monotonic()
            result = subprocess.run([str(exe), '127.0.0.1', str(listener.getsockname()[1])],
                                    capture_output=True, text=True, timeout=2)
            self.assertEqual(result.returncode, 0)
            self.assertGreaterEqual(float(result.stdout), 0)
            self.assertLess(time.monotonic() - start, 1)
        with socket.socket() as reserved:
            reserved.bind(('127.0.0.1', 0))  # Bound but not listening.
            result = subprocess.run([str(exe), '127.0.0.1', str(reserved.getsockname()[1])], timeout=4)
            self.assertNotEqual(result.returncode, 0)

    def test_kernel_lock_serializes_and_recovers_after_kill(self):
        lock = self.base / 'operation.lock'
        path = self.script('lock', (HELPERS / 'mango-lock').read_text().replace('/var/lock/mango-operation.lock', str(lock)))
        record = self.base / 'events'
        task = self.script('task', f'echo start >> "{record}"; sleep 0.2; echo end >> "{record}"')
        a = subprocess.Popen(['sh', path, task], env=self.env)
        b = subprocess.Popen(['sh', path, task], env=self.env)
        self.assertEqual(a.wait(timeout=4), 0)
        self.assertEqual(b.wait(timeout=4), 0)
        self.assertEqual(record.read_text().splitlines(), ['start', 'end', 'start', 'end'])
        nested = self.run_script(path, path, 'true')
        self.assertEqual(nested.returncode, 0, nested.stderr)
        held = subprocess.Popen(['sh', path, 'sleep', '30'], env=self.env, start_new_session=True)
        try:
            time.sleep(0.15)
            os.killpg(held.pid, signal.SIGKILL)
            held.wait(timeout=3)
        finally:
            if held.poll() is None:
                os.killpg(held.pid, signal.SIGKILL)
                held.wait()
        result = subprocess.run(['flock', '-w', '2', str(lock), 'true'], timeout=3)
        self.assertEqual(result.returncode, 0)

    def prepare_update(self, fail_start=False):
        rules = self.base / 'rules'; rules.mkdir()
        assets = self.base / 'assets'; assets.mkdir()
        status = self.base / 'status'
        count = self.base / 'restarts'
        source = (HELPERS / 'mango-update-rules').read_text()
        source = source.replace('/etc/mango-rules', str(rules)).replace('/usr/share/xray', str(assets))
        source = source.replace('/tmp/mango-update-status', str(status))
        source = source.replace('/usr/libexec/', str(self.bin) + '/')
        source = source.replace('/etc/init.d/mango_proxy', str(self.bin / 'restart'))
        source = source.replace('/tmp/mango-rules.', str(self.base / 'stage.'))
        self.env['MANGO_OPERATION_LOCK'] = '1'
        self.script('readlink', 'echo /var/lock/mango-operation.lock')
        digest = hashlib.sha256(b'new rules').hexdigest()
        self.script('mango-download', f'read url; case "$url" in *.sha256sum) echo "{digest}" > "$3";; *) printf "new rules" > "$3";; esac')
        self.script('xray', 'exit 0')
        self.script('mango-assets', 'exit 0')
        self.script('mango-generate', 'echo "{}"')
        self.script('mango-cn-cidrs', 'printf cidrs > "$2"')
        self.script('restart', f'n=$(cat "{count}" 2>/dev/null || echo 0); n=$((n+1)); echo "$n" > "{count}"; ' +
                    ('[ "$n" != 1 ]' if fail_start else 'exit 0'))
        path = self.script('update', source)
        return path, rules, assets, status, count

    def test_unchanged_builtin_rule_never_restarts(self):
        path, rules, assets, status, count = self.prepare_update()
        (assets / 'geoip.dat').write_bytes(b'new rules')
        result = self.run_script(path, 'china', 'current')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('已是最新', status.read_text())
        self.assertFalse(count.exists())
        self.assertFalse((rules / 'geoip.dat').exists())

    def test_failed_start_restores_old_rule_and_restarts(self):
        path, rules, assets, status, count = self.prepare_update(fail_start=True)
        (rules / 'geoip.dat').write_bytes(b'old rules')
        result = self.run_script(path, 'china', 'current')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((rules / 'geoip.dat').read_bytes(), b'old rules')
        self.assertEqual(count.read_text().strip(), '2')
        self.assertIn('已恢复旧规则', status.read_text())
        self.assertFalse((rules / 'china.updated').exists())

    def test_success_updates_manual_status_and_timestamp(self):
        path, rules, assets, status, count = self.prepare_update()
        result = self.run_script(path, 'china', 'current')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('退出码 0', status.read_text())
        self.assertTrue((rules / 'china.updated').exists())
        self.assertEqual((rules / 'geoip.dat').read_bytes(), b'new rules')

    def test_download_resolves_every_redirect_without_system_dns(self):
        source = (HELPERS / 'mango-download').read_text().replace('/usr/libexec/mango-resolve', str(self.bin / 'mango-resolve'))
        path = self.script('download', source)
        calls = self.base / 'resolved'
        self.script('mango-resolve', f'echo "$1" >> "{calls}"; echo 192.0.2.1')
        self.script('curl', r'''
cfg=; output=; resolved=
while [ "$#" -gt 0 ]; do
 case "$1" in --config) cfg=$2; shift;; --output) output=$2; shift;; --resolve) resolved=$2; shift;; --location) exit 91;; esac
 shift
done
[ -n "$resolved" ] || exit 92
grep -q 'noproxy = "\*"' "$cfg" || exit 93
if grep -q 'first.example' "$cfg"; then
 printf 'redirect' > "$output"
 printf '302\nhttps://second.example/final?token=private\n'
else
 printf 'content' > "$output"
 printf '200\n\n'
fi
''')
        output = self.base / 'data'
        result = self.run_script(path, 'direct', 'rules', str(output), input='https://first.example/start\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(calls.read_text().splitlines(), ['first.example', 'second.example'])
        self.assertEqual(output.read_text(), 'content')
        self.assertNotIn('private', result.stdout + result.stderr)

    def test_resolver_uses_backup_and_validates_answers(self):
        calls = self.base / 'dns-calls'
        self.script('nslookup', f'echo "$*" >> "{calls}"\n' + r'''
case "$*" in
 *223.5.5.5) echo 'Server: 223.5.5.5'; echo 'Address: 223.5.5.5:53'; exit 1;;
 *) printf 'Name: example.com\nAddress: 999.1.1.1\nAddress: 192.0.2.2\n';;
esac
''')
        result = self.run_script(HELPERS / 'mango-resolve', 'example.com')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), '192.0.2.2')
        self.assertEqual(len(calls.read_text().splitlines()), 2)
        self.assertNotEqual(self.run_script(HELPERS / 'mango-resolve', '999.0.0.1').returncode, 0)

    def test_cache_only_clears_on_policy_change(self):
        state = self.base / 'cache-state'
        modes = self.base / 'mode'; modes.write_text('global')
        calls = self.base / 'hup'
        source = (HELPERS / 'mango-cache').read_text().replace('/var/etc/mango', str(state))
        path = self.script('cache', source)
        self.script('uci', f'case "$*" in *main.mode) cat "{modes}";; *direct_domains) echo white.example;; esac')
        self.script('killall', f'echo "$*" >> "{calls}"')
        self.assertEqual(self.run_script(path).returncode, 0)
        self.assertEqual(self.run_script(path).returncode, 0)
        self.assertEqual(len(calls.read_text().splitlines()), 1)
        modes.write_text('split')
        self.assertEqual(self.run_script(path).returncode, 0)
        self.assertEqual(len(calls.read_text().splitlines()), 2)

    def test_failover_checks_backup_before_switching(self):
        state = self.base / 'state'
        state.mkdir()
        source = (HELPERS / 'mango-failover').read_text()
        source = source.replace('/usr/libexec/', str(self.bin) + '/')
        source = source.replace('/var/etc/mango', str(state))
        source = source.replace('/etc/init.d/mango_proxy', str(self.bin / 'restart'))
        path = self.script('mango-failover', source)
        self.env['MANGO_OPERATION_LOCK'] = '1'
        self.script('readlink', f'echo {self.base / "operation.lock"}')
        self.script('mango-lock', 'exec "$@"')
        self.script('uci', r'''
case "$3" in
  mango_proxy.main.failover) echo 1;;
  mango_proxy.main.mode) echo gfw;;
  mango_proxy.backup.address) echo 192.0.2.10;;
  mango_proxy.backup.port) echo 443;;
esac
''')
        self.script('curl', 'exit 1')
        self.script('mango-generate', 'echo backup')
        self.script('mango-resolve', 'echo 192.0.2.10')
        restarts = self.base / 'restarts'
        self.script('restart', f'echo yes >> "{restarts}"')
        self.script('mango-tcpcheck', 'exit 1')
        failed = self.run_script(path)
        self.assertEqual(failed.returncode, 0, failed.stderr)
        self.assertFalse((state / 'active-node').exists())
        self.assertIn('failed TCP connect', (state / 'failover-status').read_text())
        self.script('mango-tcpcheck', 'echo 1.0; exit 0')
        ready = self.run_script(path)
        self.assertEqual(ready.returncode, 0, ready.stderr)
        self.assertEqual((state / 'active-node').read_text().strip(), 'backup')
        self.assertEqual(len(restarts.read_text().splitlines()), 2)

    def test_dns_file_changes_are_atomic_and_idempotent(self):
        rules = self.base / 'rules'
        rules.mkdir()
        (rules / 'gfw-domains.txt').write_text('server=/google.com/127.0.0.1#1053\n')
        confdir = self.base / 'dnsmasq.cfg01411c.d'
        marker = self.base / 'reload-dhcp'
        source = (HELPERS / 'mango-dns').read_text()
        dirname = self.script('dns-dir', f'echo "{confdir}"')
        source = source.replace('/usr/libexec/mango-dns-dir', dirname)
        generate = self.script('dns-config', f'cat "{rules / "gfw-domains.txt"}"')
        source = source.replace('/usr/libexec/mango-dns-config', generate)
        self.script('dnsmasq', 'exit 0')
        source = source.replace('/etc/mango-rules/gfw-domains.txt', str(rules / 'gfw-domains.txt'))
        source = source.replace('/usr/share/xray/gfw-domains.txt', str(rules / 'missing.txt'))
        source = source.replace('/tmp/dnsmasq.d', str(confdir))
        source = source.replace('/var/etc/mango/reload-dhcp', str(marker))
        source = source.replace('/tmp/mango-dns.', str(self.base / 'dns.'))
        path = self.script('dns', source)
        self.script('uci', 'echo gfw')
        self.assertEqual(self.run_script(path, 'check').returncode, 0)
        self.assertFalse((confdir / 'mango-dns.conf').exists())
        first = self.run_script(path)
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual((confdir / 'mango-dns.conf').read_text(), 'server=/google.com/127.0.0.1#1053\n')
        self.assertTrue(marker.exists())
        marker.unlink()
        self.assertEqual(self.run_script(path).returncode, 0)
        self.assertFalse(marker.exists())
        (rules / 'gfw-domains.txt').write_text('')
        self.assertEqual(self.run_script(path).returncode, 0)
        self.assertEqual((confdir / 'mango-dns.conf').read_text(), '')
        self.assertTrue(marker.exists())
        marker.unlink()
        self.script('dnsmasq', 'exit 1')
        (rules / 'gfw-domains.txt').write_text('invalid')
        self.assertNotEqual(self.run_script(path).returncode, 0)
        self.assertEqual((confdir / 'mango-dns.conf').read_text(), '')
        self.assertFalse(marker.exists())
