import pathlib
import subprocess
import tempfile
import unittest
import os


@unittest.skipIf(os.name == 'nt', 'Requires POSIX shell/awk; runs on Linux build runner')
class ReadyTests(unittest.TestCase):
    def check_ports(self, ports):
        source = (pathlib.Path(__file__).resolve().parents[1] /
                  'package/luci-app-mango-proxy/root/usr/libexec/mango-ready').read_text()
        with tempfile.TemporaryDirectory() as directory:
            tcp = pathlib.Path(directory) / 'tcp'
            tcp6 = pathlib.Path(directory) / 'tcp6'
            tcp.write_text(''.join('0: 0100007F:%04X 00000000:0000 0A\n' % p for p in ports))
            tcp6.write_text('')
            script = source.replace('/proc/net/tcp6', str(tcp6)).replace('/proc/net/tcp', str(tcp))
            return subprocess.run(['sh', '-c', script], check=False).returncode

    def test_all_required_ports(self):
        self.assertEqual(self.check_ports([1053, 10808, 10809, 12345]), 0)

    def test_partial_startup(self):
        for absent in [1053, 10808, 10809, 12345]:
            self.assertNotEqual(self.check_ports([p for p in [1053, 10808, 10809, 12345] if p != absent]), 0)

    def test_no_listeners(self):
        self.assertNotEqual(self.check_ports([]), 0)
