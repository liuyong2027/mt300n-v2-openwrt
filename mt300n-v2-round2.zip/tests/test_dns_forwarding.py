"""Use real dnsmasq with a local DNS responder; Xray is deliberately absent."""
import os
from pathlib import Path
import shutil
import socket
import struct
import subprocess
import tempfile
import threading
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]

@unittest.skipUnless(shutil.which('dnsmasq') and shutil.which('lua5.1'), 'Real resolver test runs in runtime validation')
class DNSForwardingTests(unittest.TestCase):
    def test_cn_survives_missing_core_and_global_has_no_cn_bypass(self):
        upstream=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        upstream.bind(('127.0.0.1',0)); upstream.settimeout(.1)
        stop=threading.Event()
        def responder():
            while not stop.is_set():
                try: data,addr=upstream.recvfrom(4096)
                except socket.timeout: continue
                answer=data[:2]+b'\x81\x80'+b'\x00\x01\x00\x01\x00\x00\x00\x00'+data[12:]+b'\xc0\x0c\x00\x01\x00\x01\x00\x00\x00\x01\x00\x04\x01\x02\x03\x04'
                upstream.sendto(answer,addr)
        t=threading.Thread(target=responder); t.start()
        try:
            for mode in ['split','global']:
                lua="local m=dofile('package/luci-app-mango-proxy/root/usr/lib/mango/dns.lua'); io.write(m.render('"+mode+"',{'baidu.com'},nil,{'direct.example'}))"
                rules=subprocess.check_output(['lua5.1','-e',lua],cwd=ROOT,text=True)
                # Keep an unreachable local socket as the unavailable Xray DNS server.
                with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as dead, socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as alloc:
                    dead.bind(('127.0.0.1',0)); alloc.bind(('127.0.0.1',0)); port=alloc.getsockname()[1]; alloc.close()
                    address='127.0.0.1#'+str(upstream.getsockname()[1])
                    rules=rules.replace('223.5.5.5',address).replace('119.29.29.29',address)
                    with tempfile.TemporaryDirectory() as tmp:
                        conf=Path(tmp)/'dns.conf'
                        conf.write_text(f'port={port}\nlisten-address=127.0.0.1\nbind-interfaces\nno-resolv\nno-hosts\ncache-size=0\nserver=127.0.0.1#{dead.getsockname()[1]}\n'+rules)
                        proc=subprocess.Popen(['dnsmasq','--keep-in-foreground','--conf-file='+str(conf),'--pid-file='+tmp+'/pid'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
                        try:
                            time.sleep(.2); self.assertIsNone(proc.poll())
                            for domain,expected in [('www.baidu.com',mode=='split'),('www.google.com',False),('direct.example',True)]:
                                query=b'\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00'+b''.join(bytes([len(x)])+x.encode() for x in domain.split('.'))+b'\x00\x00\x01\x00\x01'
                                with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as client:
                                    client.settimeout(.4); client.sendto(query,('127.0.0.1',port))
                                    try: data=client.recv(4096); answered=data.endswith(b'\x01\x02\x03\x04')
                                    except socket.timeout: answered=False
                                self.assertEqual(answered,expected,(mode,domain))
                        finally:
                            proc.terminate(); proc.communicate(timeout=3)
        finally:
            stop.set(); t.join(timeout=2); upstream.close()
