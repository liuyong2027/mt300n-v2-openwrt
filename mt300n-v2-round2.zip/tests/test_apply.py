import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
HELPERS=ROOT/'package/luci-app-mango-proxy/root/usr/libexec'

@unittest.skipIf(os.name=='nt', 'Linux queue tests run in CI')
class ApplyTests(unittest.TestCase):
    def test_requests_during_running_apply_are_not_lost_and_failure_is_visible(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp); state=base/'state'; state.mkdir(); locks=base/'locks'; locks.mkdir()
            helper=base/'apply'; init=base/'init'; events=base/'events'
            text=(HELPERS/'mango-apply-job').read_text().replace('/var/etc/mango',str(state)).replace('/var/lock',str(locks)).replace('/usr/libexec/mango-apply-job',str(helper)).replace('/etc/init.d/mango_proxy',str(init))
            helper.write_text(text); helper.chmod(0o755)
            init.write_text(f'#!/bin/sh\necho start >> "{events}"\nsleep 0.3\necho end >> "{events}"\nexit 1\n'); init.chmod(0o755)
            start=time.monotonic()
            subprocess.run([str(helper),'request'],check=True,timeout=2)
            self.assertLess(time.monotonic()-start,1)
            for _ in range(100):
                if events.exists(): break
                time.sleep(.02)
            self.assertTrue(events.exists())
            subprocess.run([str(helper),'request'],check=True,timeout=2)
            for _ in range(150):
                if events.read_text().splitlines()==['start','end','start','end']: break
                time.sleep(.02)
            self.assertEqual(events.read_text().splitlines(),['start','end','start','end'])
            for _ in range(50):
                if '退出码 1' in (state/'apply-status').read_text(): break
                time.sleep(.02)
            self.assertIn('退出码 1',(state/'apply-status').read_text())
            self.assertFalse((state/'apply-pending').exists())

    def test_test_site_error_categories_without_live_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp)
            def exe(name,text):
                p=base/name; p.write_text('#!/bin/sh\n'+text); p.chmod(0o755); return p
            jsh=base/'jshn'; jsh.write_text('json_init() { :; }; json_add_int() { echo "$1=$2"; }; json_add_string() { echo "$1=$2"; }; json_dump() { :; }\n')
            ready=exe('ready','exit "${READY:-0}"\n')
            exe('uci','echo global\n')
            exe('curl','printf "${HTTP:-000} 0.2"; exit "$CODE"\n')
            helper=exe('test-site',(HELPERS/'mango-test-site').read_text().replace('/usr/share/libubox/jshn.sh',str(jsh)).replace('/usr/libexec/mango-ready',str(ready)))
            env={**os.environ,'PATH':str(base)+':'+os.environ['PATH']}
            for code,category in [(6,'dns'),(7,'connect'),(28,'timeout'),(60,'tls'),(97,'proxy'),(56,'transfer'),(0,'http')]:
                r=subprocess.run([str(helper),'baidu','current'],env={**env,'CODE':str(code)},capture_output=True,text=True,check=True)
                self.assertIn('category='+category,r.stdout)
            r=subprocess.run([str(helper),'baidu','current'],env={**env,'CODE':'0','HTTP':'200'},capture_output=True,text=True,check=True)
            self.assertIn('category=ok',r.stdout)
            r=subprocess.run([str(helper),'baidu','current'],env={**env,'READY':'1'},capture_output=True,text=True,check=True)
            self.assertIn('category=core',r.stdout)
