const fs=require('node:fs'), vm=require('node:vm'), assert=require('node:assert/strict');
const source=fs.readFileSync('package/luci-app-mango-proxy/htdocs/luci-static/resources/mango/subscription.js','utf8');
const parser=vm.runInNewContext('(function(){'+source+'\n})()', {baseclass:{extend:v=>v},URL,atob});
const good='vless://00000000-0000-4000-8000-000000000001@node.example.com:443?type=tcp&security=reality&flow=xtls-rprx-vision&sni=www.example.com&pbk=CQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA&sid=0123#Test';
assert.equal(parser.parse(good).nodes[0].label,'Test');
assert.equal(parser.parse(Buffer.from(good).toString('base64')).nodes.length,1);
assert.equal(parser.parse(good+'\n'+good).nodes.length,1);
assert.equal(parser.parse(good+'\n'+good.replace('type=tcp','type=ws')).skipped,1);
assert.throws(()=>parser.parse(good.replace('security=reality','security=tls')));
assert.throws(()=>parser.parse(good.replace('sid=0123','sid=f')));
assert.throws(()=>parser.parse('<html>Login</html>'));
assert.throws(()=>parser.parse('x'.repeat(49153)));
console.log('Subscription parser tests passed');

assert.equal(parser.parse(Buffer.from(good.replace('type=tcp','type=tcp&fp=ios')).toString('base64')).nodes[0].fingerprint,'ios');
assert.throws(()=>parser.parse(good.replace('type=tcp','type=tcp&fp=unknown')));

assert.equal(parser.parse(good.replace('#Test','#'+encodeURIComponent('剩余流量：10 GB'))+'\n'+good).nodes[0].label,'Test');

// Same endpoint/account but different connection parameters must remain distinct.
for (const variant of [
    good.replace('sid=0123','sid=4567'),
    good.replace('pbk=CQ','pbk=DQ'),
    good.replace('type=tcp','type=tcp&fp=ios'),
    good.replace('type=tcp','type=tcp&spx=%2Fprobe')
]) {
    const nodes=parser.parse(good+'\n'+variant).nodes;
    assert.equal(nodes.length,2);
    assert.notEqual(parser.identity(nodes[0]),parser.identity(nodes[1]));
}
const original=parser.parse(good).nodes[0];
assert.equal(parser.identity(original),parser.identity({...original, label:'Renamed',port:443}));
const many=Array.from({length:54},(_,i)=>good.replace('sid=0123','sid='+i.toString(16).padStart(4,'0'))).join('\n');
assert.equal(parser.parse(Buffer.from(many).toString('base64')).nodes.length,54);
const existing=new Map([[parser.identity(original),'saved-node']]);
const again=parser.parse(good+'\n'+good.replace('sid=0123','sid=4567')).nodes;
assert.equal(again.filter(n=>existing.has(parser.identity(n))).length,1);
console.log('Full-parameter dedup passed: Short ID, public key, fingerprint, path, 54 nodes, existing-node matching');

const noticeLink=good.replace('#Test','#'+encodeURIComponent('套餐到期：长期有效'));
const withNotices=parser.parse(noticeLink+'\n'+good);
assert.equal(withNotices.nodes.length,1);
assert.equal(withNotices.notices[0],'套餐到期：长期有效');
assert.equal(withNotices.skipped,0);
assert.equal(parser.isNotice('香港流量优化节点'),false);
console.log('Subscription notices separated from nodes');
