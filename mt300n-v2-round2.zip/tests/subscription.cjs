const fs=require('node:fs'), vm=require('node:vm'), assert=require('node:assert/strict');
const source=fs.readFileSync('package/luci-app-mango-proxy/htdocs/luci-static/resources/mango/subscription.js','utf8');
const parser=vm.runInNewContext('(function(){'+source+'\n})()', {baseclass:{extend:v=>v},URL,atob});
const good='vless://00000000-0000-4000-8000-000000000001@node.example.com:443?type=tcp&security=reality&flow=xtls-rprx-vision&sni=www.example.com&pbk=CQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA&sid=0123#Test';
assert.equal(parser.parse(good).nodes[0].label,'Test');
assert.equal(parser.parse(Buffer.from(good).toString('base64')).nodes.length,1);
assert.equal(parser.parse(good+'\n'+good).nodes.length,1);
assert.equal(parser.parse(good+'\n'+good.replace('type=tcp','type=ws')).skipped,1);
assert.throws(()=>parser.parse(good.replace('security=reality','security=tls')));
assert.throws(()=>parser.parse(good.replace('sid=0123','sid=f')));
assert.throws(()=>parser.parse('<html>Login</html>'));
assert.throws(()=>parser.parse('x'.repeat(49153)));
console.log('Subscription parser tests passed');

assert.equal(parser.parse(Buffer.from(good.replace('type=tcp','type=tcp&fp=ios')).toString('base64')).nodes[0].fingerprint,'ios');
assert.throws(()=>parser.parse(good.replace('type=tcp','type=tcp&fp=unknown')));

assert.equal(parser.parse(good.replace('#Test','#'+encodeURIComponent('剩余流量：10 GB'))+'\n'+good).nodes[0].label,'Test');
