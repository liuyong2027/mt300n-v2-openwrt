local M = dofile('package/luci-app-mango-proxy/root/usr/lib/mango/model.lua')
local n = {address='node.example.com',port='443',sni='www.example.com',
    uuid='00000000-0000-4000-8000-000000000001',public_key='CQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    short_id='0123456789abcdef',fingerprint='chrome'}
assert(M.ip4('192.168.1.0/24'))
assert(not M.ip4('1.2.3.999'))
assert(not M.ip4('1.2.3.4/33'))
assert(not M.ip4('1.2.3.4; flush ruleset'))
assert(not pcall(M.policy,{mode='global',lan_device='x";drop'}))
assert(not pcall(M.xray,{mode='global'},nil))
local invalid = {}; for k,v in pairs(n) do invalid[k]=v end
invalid.short_id='f'; assert(not pcall(M.node,invalid))
for _, mode in ipairs({'direct','split','global'}) do
    local p = {mode=mode,lan_device='br-lan',zt_gateway='1',zt_sources={'10.147.17.5/32'},zt_routes={'198.51.100.0/24'}}
    local config = M.xray(p,n)
    local json = M.json(config)
    local nft = M.nft(p)
    assert(not nft:find('hook output',1,true), 'ZeroTier underlay must not be proxied')
    assert(nft:find('ip saddr @zt_sources return',1,true))
    assert(nft:find('198.51.100.0/24',1,true))
    if mode == 'direct' then
        assert(not nft:find('tproxy ip',1,true))
        assert(not json:find('"tag":"proxy"',1,true))
    else
        assert(nft:find('tproxy ip to 127.0.0.1:12345',1,true))
        assert(nft:find('ct direction reply return',1,true))
        assert(nft:find('jump fail_closed',1,true))
        assert(nft:find('chain fail_closed',1,true))
        assert(json:find('xtls-rprx-vision',1,true))
        assert(json:find('IPIfNonMatch',1,true))
    end
    assert((json:find('geosite:cn',1,true) ~= nil) == (mode == 'split'))
    assert((json:find('geoip:cn',1,true) ~= nil) == (mode == 'split'))
    local f=assert(io.open('reports/test-' .. mode .. '.json','w')); f:write(json); f:close()
    f=assert(io.open('reports/test-' .. mode .. '.nft','w')); f:write(nft); f:close()
end
local off=M.nft({mode='global',zt_gateway='0',zt_sources={'10.1.1.1'}})
assert(not off:find('set zt_sources',1,true))
assert(off:find('chain zt_guard {\nct state established,related ct direction reply return\ndrop',1,true))
print('Policy tests passed: three modes, node validation, ZeroTier allowlist, underlay bypass and forwarding guard')
