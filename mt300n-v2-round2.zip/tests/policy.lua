local M = dofile('package/luci-app-mango-proxy/root/usr/lib/mango/model.lua')
local n = {address='node.example.com',port='443',sni='www.example.com',
    uuid='00000000-0000-4000-8000-000000000001',public_key='CQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    short_id='0123456789abcdef',fingerprint='chrome'}
assert(M.ip4('192.168.1.0/24'))
assert(not M.ip4('1.2.3.999'))
assert(not M.ip4('1.2.3.4/33'))
assert(not M.ip4('1.2.3.4; flush ruleset'))
assert(not pcall(M.policy,{mode='global',lan_device='x";drop'}))
assert(not pcall(M.xray,{mode='global'},nil))
local invalid = {}; for k,v in pairs(n) do invalid[k]=v end
invalid.short_id='f'; assert(not pcall(M.node,invalid))
for _, mode in ipairs({'direct','split','global','gfw'}) do
    local p = {mode=mode,lan_device='br-lan',zt_gateway='1',zt_sources={'10.147.17.5/32'},zt_routes={'198.51.100.0/24'}}
    p.gfw_proxy={'domain:google.com'}; p.gfw_direct={'domain:example.com'}
    local gfpath='package/luci-app-mango-proxy/root/usr/share/xray/gfw-domains.txt'
    local gf=io.open(gfpath,'r')
    if mode=='gfw' and gf then
        gf:close()
        p.gfw_proxy,p.gfw_direct=dofile('package/luci-app-mango-proxy/root/usr/lib/mango/gfw.lua').load(gfpath)
    elseif gf then gf:close() end
    p.direct_domains={'white.example.com'}
    local config = M.xray(p,n)
    assert(config.dns.disableFallbackIfMatch)
    assert(config.routing.rules[2].ip[2]=='119.29.29.29')
    assert(config.routing.rules[2].outboundTag=='direct')
    for i=1,#config.dns.servers,2 do
        local a,b=config.dns.servers[i],config.dns.servers[i+1]
        assert(b,'Every DNS group needs a backup')
        if type(a)=='table' then
            assert(a.domains==b.domains and a.skipFallback and b.skipFallback)
            assert((a.address=='223.5.5.5' and b.address=='119.29.29.29') or (a.address=='1.1.1.1' and b.address=='8.8.8.8'))
        else
            assert((a=='223.5.5.5' and b=='119.29.29.29') or (a=='1.1.1.1' and b=='8.8.8.8'))
        end
    end
    local json = M.json(config)
    local whiteIndex,proxyIndex
    for i,r in ipairs(config.routing.rules) do
        if r.domain and r.domain[1]=='domain:white.example.com' then whiteIndex=i; assert(r.outboundTag=='direct') end
        if r.domain and r.domain[1]=='domain:google.com' then proxyIndex=i end
    end
    assert(whiteIndex)
    if proxyIndex then assert(whiteIndex<proxyIndex) end
    local nft = M.nft(p)
    assert(not nft:find('hook output',1,true), 'ZeroTier underlay must not be proxied')
    assert(nft:find('ip saddr @zt_sources return',1,true))
    assert(nft:find('198.51.100.0/24',1,true))
    if mode == 'direct' then
        assert(not nft:find('tproxy ip',1,true))
        assert(not json:find('"tag":"proxy"',1,true))
    else
        assert(nft:find('tproxy ip to 127.0.0.1:12345',1,true))
        assert(nft:find('ct direction reply return',1,true))
        assert(nft:find('jump fail_closed',1,true))
        assert(nft:find('chain fail_closed',1,true))
        assert(json:find('xtls-rprx-vision',1,true))
        assert(json:find('IPIfNonMatch',1,true))
    end
    assert((json:find('geosite:cn',1,true) ~= nil) == (mode == 'split'))
    assert((json:find('geoip:cn',1,true) ~= nil) == (mode == 'split'))
    if mode == 'gfw' then
        assert(config.routing.rules[#config.routing.rules].outboundTag=='direct')
        assert(json:find('domain:google.com',1,true))
        assert(config.routing.rules[3].outboundTag=='proxy')
    end
    local f=assert(io.open('reports/test-' .. mode .. '.json','w')); f:write(json); f:close()
    f=assert(io.open('reports/test-' .. mode .. '.nft','w')); f:write(nft); f:close()
end
local off=M.nft({mode='global',zt_gateway='0',zt_sources={'10.1.1.1'}})
assert(not off:find('set zt_sources',1,true))
assert(off:find('chain zt_guard {\nct state established,related ct direction reply return\ndrop',1,true))
print('Policy tests passed: three modes, node validation, ZeroTier allowlist, underlay bypass and forwarding guard')
local F=dofile('package/luci-app-mango-proxy/root/usr/lib/mango/failover.lua')
local p={node='primary',backup_nodes={'backup1','primary','backup2','missing'},failover='1'}
local function exists(id) return id~='missing' end
local ids=F.candidates(p,exists)
assert(#ids==3 and ids[1]=='primary' and ids[2]=='backup1')
assert(F.next(ids,'primary')=='backup1')
assert(F.next(ids,'backup2')=='primary')
assert(F.active(p,'backup1',exists)=='backup1')
assert(F.active(p,'unknown',exists)=='primary')
p.failover='0'; assert(F.active(p,'backup1',exists)=='primary')
assert(F.next({'only'},'only')==nil)
print('Failover candidate tests passed')
