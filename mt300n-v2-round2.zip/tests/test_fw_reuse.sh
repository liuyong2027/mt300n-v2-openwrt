#!/bin/sh
set -eu
t=$(mktemp -d /tmp/mango-fw-reuse-test.XXXXXX)
trap 'rm -rf "$t"' EXIT
export TEST_DIR="$t"
mkdir -p "$t/bin" "$t/state"
sed -e "s|/usr/libexec/|$t/bin/|g" -e "s|/var/etc/mango|$t/state|g" "$1" > "$t/init"
cat > "$t/bin/mango-fw-state" <<'EOF'
#!/bin/sh
[ ! -f "$TEST_DIR/read-fail" ] || exit 1
cat "$TEST_DIR/desired"
[ "${1:-}" = desired ] || cat "$TEST_DIR/actual" "$TEST_DIR/routing"
EOF
cat > "$t/bin/mango-fw" <<'EOF'
#!/bin/sh
echo apply >> "$TEST_DIR/calls"
[ ! -f "$TEST_DIR/install-fail" ] || exit 19
if [ -f "$TEST_DIR/mutate" ]; then echo changed > "$TEST_DIR/desired"; fi
EOF
chmod +x "$t/bin/"*
cat > "$t/run" <<'EOF'
#!/bin/sh
. "$TEST_DIR/init"
action=restart
reset() {
 mango_fw_restart_state=
 echo d > "$TEST_DIR/desired"
 echo a > "$TEST_DIR/actual"
 echo r > "$TEST_DIR/routing"
 : > "$TEST_DIR/calls"
 rm -f "$TEST_DIR/read-fail" "$TEST_DIR/install-fail" "$TEST_DIR/mutate"
}
count() { [ "$(wc -l < "$TEST_DIR/calls")" = "$1" ] || exit 81; }
reset
mango_guard && mango_guard || exit 1
count 1
echo 'PASS unchanged restart installs once'
for field in desired actual routing; do
 reset
 mango_guard || exit 1
 echo changed >> "$TEST_DIR/$field"
 mango_guard || exit 1
 count 2
 echo "PASS changed $field reinstalls"
done
reset
touch "$TEST_DIR/install-fail"
mango_guard; rc=$?
[ "$rc" = 19 ] && [ -z "$mango_fw_restart_state" ] || exit 2
rm "$TEST_DIR/install-fail"
mango_guard || exit 1
count 2
echo 'PASS failed installation never reused'
reset
mango_guard || exit 1
touch "$TEST_DIR/read-fail"
mango_guard || exit 1
count 2
echo 'PASS read failure reinstalls'
reset
touch "$TEST_DIR/mutate"
mango_guard && mango_guard || exit 1
count 2
echo 'PASS changes during install prevent reuse'
for action in start stop boot; do
 reset
 mango_guard && mango_guard || exit 1
 count 2
 echo "PASS standalone $action always installs"
done
EOF
sh "$t/run"
