#!/bin/sh
set -eu
t=$(mktemp -d /tmp/mango-recovery-test.XXXXXX)
trap 'rm -rf "$t"' EXIT
export TEST_DIR="$t"
mkdir -p "$t/state" "$t/bin"
sed "s|/var/etc/mango|$t/state|g" "$1" > "$t/init"
cat > "$t/runner" <<'EOF'
#!/bin/sh
. "$TEST_DIR/init"
MANGO_RECOVERY_TRACE=1
mango_timed test-ok true || exit 1
mango_timed test-fail sh -c 'exit 23'; rc=$?
[ "$rc" = 23 ] || exit 2
# Simulate unavailable diagnostic destination: operation result must survive.
rm "$TEST_DIR/state/recovery-timing"
mkdir "$TEST_DIR/state/recovery-timing"
mango_timed no-log true || exit 3
mango_timed no-log-fail sh -c 'exit 24'; rc=$?
[ "$rc" = 24 ] || exit 4
rmdir "$TEST_DIR/state/recovery-timing"
EOF
sh "$t/runner"
grep -q 'test-fail seconds=.* rc=23' "$t/state/apply-timing"
echo 'PASS success/failure codes unchanged despite diagnostic write failure'
cat > "$t/bin/mock" <<'EOF'
#!/bin/sh
case "${0##*/}" in
 uci) case "$*" in *failover) echo 1;; *mode) echo split;; *node) echo node1;; esac;;
 mango-probe) exit 1;;
 mango-generate) exit 0;;
 logger|mango-node-log) exit 0;;
 mango_proxy)
  [ "$MANGO_RECOVERY_TRACE" = 1 ] || exit 99
  echo simulated-stage >> "$TEST_DIR/state/recovery-timing"
  exit "$(cat "$TEST_DIR/result")";;
esac
EOF
chmod +x "$t/bin/mock"
for n in uci mango-probe mango-generate logger mango-node-log mango_proxy; do ln -s mock "$t/bin/$n"; done
export PATH="$t/bin:$PATH"
# Remove only the real locking preamble in the isolated copy.
sed -e '/^if \[ "${MANGO_OPERATION_LOCK:-}"/,/^fi$/d' -e "s|/var/etc/mango|$t/state|g" -e "s|/usr/libexec/|$t/bin/|g" -e "s|/etc/init.d/|$t/bin/|g" "$2" > "$t/failover"
echo previous > "$t/state/recovery-timing"
echo 0 > "$t/result"
sh "$t/failover"
grep -q previous "$t/state/recovery-timing.previous"
grep -q 'recovery-end=.*rc=0' "$t/state/recovery-timing"
echo 17 > "$t/result"
if sh "$t/failover"; then exit 1; else [ "$?" = 17 ]; fi
grep -q 'recovery-end=.*rc=17' "$t/state/recovery-timing"
grep -q 'recovery-end=.*rc=0' "$t/state/recovery-timing.previous"
echo 'PASS recovery success/failure preserved and last two traces retained'
