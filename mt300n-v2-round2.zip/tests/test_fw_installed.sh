#!/bin/sh
set -eu
t=$(mktemp -d /tmp/mango-fw-installed.XXXXXX)
trap 'rm -rf "$t"' EXIT
export TEST_DIR="$t"
mkdir -p "$t/bin" "$t/state"
sed -e "s|/usr/libexec/|$t/bin/|g" -e "s|/usr/sbin/nft|$t/bin/nft|g" -e "s|/var/etc/mango|$t/state|g" "$1" > "$t/fw"
export PATH="$t/bin:$PATH"
cat > "$t/bin/mango-generate" <<'EOF'
#!/bin/sh
cat "$TEST_DIR/desired"
EOF
cat > "$t/bin/mango-fw-state" <<'EOF'
#!/bin/sh
[ ! -f "$TEST_DIR/read-fail" ] || exit 1
sha256sum "$TEST_DIR/desired" | cut -d ' ' -f 1
cat "$TEST_DIR/actual" "$TEST_DIR/routing"
EOF
cat > "$t/bin/nft" <<'EOF'
#!/bin/sh
echo "$1" >> "$TEST_DIR/calls"
[ ! -f "$TEST_DIR/install-fail" ]
EOF
cat > "$t/bin/uci" <<'EOF'
#!/bin/sh
echo direct
EOF
cat > "$t/bin/ip" <<'EOF'
#!/bin/sh
exit 0
EOF
chmod +x "$t/bin/"*
echo desired > "$t/desired"
echo actual > "$t/actual"
echo routing > "$t/routing"
: > "$t/calls"
sh "$t/fw" reuse
[ "$(wc -l < "$t/calls")" = 2 ]
sh "$t/fw" reuse
[ "$(wc -l < "$t/calls")" = 2 ]
echo 'PASS first install, unchanged restart skips both nft transactions'
for field in desired actual routing; do
 : > "$t/calls"
 echo changed >> "$t/$field"
 sh "$t/fw" reuse
 [ "$(wc -l < "$t/calls")" = 2 ]
done
echo 'PASS desired, kernel table and routing changes reinstall'
: > "$t/calls"
sh "$t/fw"
[ "$(wc -l < "$t/calls")" = 2 ]
echo 'PASS ordinary firewall invocation always installs'
touch "$t/read-fail"
sh "$t/fw" reuse
[ ! -f "$t/state/fw-installed-state" ]
rm "$t/read-fail"
sh "$t/fw" reuse
touch "$t/install-fail"
echo changed >> "$t/desired"
if sh "$t/fw" reuse; then exit 1; fi
[ ! -f "$t/state/fw-installed-state" ]
echo 'PASS read/install failures invalidate reuse'
