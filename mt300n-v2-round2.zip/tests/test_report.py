import importlib.util
import json
from pathlib import Path
import tempfile
from contextlib import contextmanager
import uuid
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('capacity', Path(__file__).parents[1] / 'scripts/report.py')
report = importlib.util.module_from_spec(spec)
spec.loader.exec_module(report)

@contextmanager
def scratch():
    # Python's Windows 0700 temporary-directory ACL conflicts with restricted tokens.
    parent = Path(tempfile.gettempdir()).resolve()
    directory = parent / ('mt300n-test-' + uuid.uuid4().hex)
    directory.mkdir(mode=0o777)
    try:
        yield str(directory)
    finally:
        assert directory.resolve().is_relative_to(parent)
        for path in sorted(directory.rglob('*'), key=lambda p: len(p.parts), reverse=True):
            assert path.resolve().is_relative_to(directory.resolve())
            if path.is_dir():
                path.rmdir()
            else:
                path.unlink()
        directory.rmdir()

class CapacityTests(unittest.TestCase):
    def test_missing_packages_rejected(self):
        with scratch() as d:
            p = Path(d) / 'image.bin'
            p.write_bytes(b'test image')
            result = report.inspect_image(p, 16064 * 1024, {'luci'})
            self.assertFalse(result['preliminary_capacity_pass'])
            self.assertIn('xray-core', result['missing_packages'])

    def test_reserved_space_enforced(self):
        with scratch() as d:
            p = Path(d) / 'image.bin'
            p.write_bytes(b'x' * (2 * 1024 * 1024))
            self.assertFalse(report.inspect_image(p, 3 * 1024 * 1024 - 1, report.required)['preliminary_capacity_pass'])
            self.assertTrue(report.inspect_image(p, 3 * 1024 * 1024, report.required)['preliminary_capacity_pass'])

    def test_no_image_is_failure_and_report_is_written(self):
        with scratch() as d:
            root = Path(d)
            out = root / 'reports'
            out.mkdir()
            with patch.multiple(report, ROOT=root, OUT=out, OW=root / 'openwrt'):
                with patch.dict('os.environ', {'BUILD_OUTCOME': 'failure', 'GITHUB_STEP_SUMMARY': ''}):
                    self.assertEqual(report.main(), 1)
            result = json.loads((out / 'capacity.json').read_text())
            self.assertFalse(result['ready_to_flash'])
            self.assertEqual(result['images'], [])

if __name__ == '__main__':
    unittest.main()
