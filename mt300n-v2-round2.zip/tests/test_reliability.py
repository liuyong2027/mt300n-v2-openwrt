import os
import subprocess
import tempfile
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'package/luci-app-mango-proxy/root'
@unittest.skipIf(os.name=='nt','Linux shell integration')
class ReliabilityTests(unittest.TestCase):
    def test_probe_requires_curl_success_and_accepts_second_target(self):
        for codes, expected, count in [('204:28 204:0',0,2),('500:0 000:28',1,2),('204:0 500:0',0,1)]:
            with self.subTest(codes=codes), tempfile.TemporaryDirectory() as tmp:
                d=Path(tmp); (d/'codes').write_text(codes.replace(' ','\n')+'\n')
                mock=d/'curl'
                mock.write_text('#!/bin/sh\nline=$(head -n1 "$TEST_DIR/codes"); sed 1d "$TEST_DIR/codes" > "$TEST_DIR/next"; mv "$TEST_DIR/next" "$TEST_DIR/codes"; echo call >> "$TEST_DIR/calls"; echo "${line%:*}"; exit "${line#*:}"\n')
                mock.chmod(0o755)
                result=subprocess.run(['sh',str(BASE/'usr/libexec/mango-probe')],env={**os.environ,'PATH':str(d)+':'+os.environ['PATH'],'TEST_DIR':tmp})
                self.assertEqual(result.returncode,expected)
                self.assertEqual(len((d/'calls').read_text().splitlines()),count)
    def test_reload_failure_boundaries(self):
        for failure in ['dns-check','xray','configure','dns','firewall','start']:
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as tmp:
                d=Path(tmp); state=d/'state';state.mkdir()
                (state/'active-node').write_text('working')
                (state/'runtime-state').write_text('global\nworking\noldhash\n')
                def exe(name,body):
                    p=d/name;p.write_text('#!/bin/sh\n'+body);p.chmod(0o755);return str(p)
                exe('uci','echo gfw\n')
                helper=exe('helper', 'exit 0\n')
                dns=exe('dns', 'if [ "$1" = check ]; then [ "$FAIL" != dns-check ]; else [ "$FAIL" != dns ]; fi\n')
                gen=exe('gen','[ "$1" != configure ] || [ "$FAIL" != configure ]\n')
                xray=exe('xray','[ "$FAIL" != xray ]\n')
                fw=exe('fw','[ "$FAIL" != firewall ]\n')
                s=(BASE/'etc/init.d/mango_proxy').read_text().replace('/var/etc/mango',str(state)).replace('/usr/bin/xray',xray)
                for name,target in [('mango-assets',helper),('mango-node-log',helper),('mango-generate',gen),('mango-dns',dns),('mango-fw',fw)]:
                    s=s.replace('/usr/libexec/'+name,target)
                s+='\nstop() { :; }\nstart() { [ "$FAIL" != start ]; }\nreload_service\n'
                p=d/'init';p.write_text(s)
                result=subprocess.run(['sh',str(p)],env={**os.environ,'PATH':str(d)+':'+os.environ['PATH'],'FAIL':failure},capture_output=True)
                self.assertNotEqual(result.returncode,0)
                self.assertEqual((state/'runtime-state').read_text(),'global\nworking\noldhash\n')
                self.assertEqual((state/'runtime-uncertain').exists(),failure not in ['dns-check','xray'])
                if failure in ['dns-check','xray']:
                    self.assertEqual((state/'active-node').read_text(),'working')
                    self.assertFalse((state/'reload-dhcp').exists())
                    self.assertFalse((state/'reload-firewall').exists())
if __name__=='__main__': unittest.main()
