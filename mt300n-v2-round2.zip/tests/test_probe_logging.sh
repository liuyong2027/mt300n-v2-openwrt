#!/bin/sh
set -eu
root=${1:-.}/package/luci-app-mango-proxy/root
t=$(mktemp -d /tmp/mango-probe-test.XXXXXX)
trap 'rm -rf "$t"' EXIT
mkdir "$t/state" "$t/locks" "$t/bin"
export TEST_DIR="$t"
sed -e "s|/var/etc/mango|$t/state|g" -e "s|/var/lock|$t/locks|g" \
    "$root/usr/libexec/mango-probe" > "$t/probe"
cat > "$t/bin/curl" <<'EOF'
#!/bin/sh
printf '%s\n' "$*" >> "$TEST_DIR/calls"
line=$(head -n 1 "$TEST_DIR/responses")
sed 1d "$TEST_DIR/responses" > "$TEST_DIR/next"
mv "$TEST_DIR/next" "$TEST_DIR/responses"
printf '%s connect=0.010 tls=1.100 first=1.200 total=1.300' "${line%:*}"
if [ "${line#*:}" != 0 ]; then printf 'mock error\nsecond line\tend\n' >&2; fi
exit "${line#*:}"
EOF
cat > "$t/bin/uci" <<'EOF'
#!/bin/sh
echo configured-node
EOF
cat > "$t/bin/pidof" <<'EOF'
#!/bin/sh
echo 123
EOF
chmod +x "$t/bin/"*
export PATH="$t/bin:$PATH"
printf 'split\nconfirmed-node\nhash\n' > "$t/state/runtime-state"
run_case() {
    responses=$1 expected=$2 count=$3
    printf '%s\n' "$responses" | tr ' ' '\n' > "$t/responses"
    : > "$t/calls"
    if sh "$t/probe"; then rc=0; else rc=$?; fi
    [ "$rc" = "$expected" ]
    [ "$(wc -l < "$t/calls")" = "$count" ]
    grep -q -- '--proxy socks5h://127.0.0.1:10809 --connect-timeout 4 --max-time 8 --max-filesize 65536' "$t/calls"
    echo "PASS $responses: rc=$expected calls=$count"
}
run_case '204:28 204:0' 0 2
grep -q 'result=ok.*www.google.com {rc=28.*cp.cloudflare.com {rc=0' "$t/state/probe-history"
grep -q 'error=mock error second line end' "$t/state/probe-history"
run_case '500:0 000:28' 1 2
grep -q 'result=failed' "$t/state/probe-history"
run_case '204:0 500:0' 0 1
run_case '302:0' 0 1
touch "$t/state/runtime-uncertain"
run_case '204:0' 0 1
tail -n 1 "$t/state/probe-history" | grep -q 'configured=configured-node confirmed=confirmed-node uncertain=1 pid_start=123 pid_end=123'
echo 'PASS node context and uncertain runtime are explicit'
for i in 1 2 3 4 5 6 7 8 9 10 11; do
    printf '204:0\n' > "$t/responses"
    sh "$t/probe"
done
[ "$(wc -l < "$t/state/probe-history")" = 10 ]
[ -z "$(find "$t/state" -name 'probe-error.*')" ]
echo 'PASS bounded ten-round log and temporary-file cleanup'
# A busy log lock must not turn a successful probe into a failure or delay it.
exec 6>"$t/locks/mango-probe-log.lock"
flock -n 6
cp "$t/state/probe-history" "$t/log-before"
run_case '204:0' 0 1
cmp -s "$t/log-before" "$t/state/probe-history"
flock -u 6
echo 'PASS logging contention preserves probe result'
rm -f "$t/state/runtime-uncertain" "$t/state/runtime-state"
run_case '204:0' 0 1
tail -n 1 "$t/state/probe-history" | grep -q 'confirmed= uncertain=1'
echo 'PASS missing runtime record is never marked confirmed'
