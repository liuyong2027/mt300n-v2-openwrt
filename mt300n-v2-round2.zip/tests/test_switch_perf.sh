#!/bin/sh
# Run against a source tree with all service/config paths redirected to a private fixture.
set -eu
root=${1:-.}/package/luci-app-mango-proxy/root
t=$(mktemp -d /tmp/mango-switch-test.XXXXXX)
trap 'rm -rf "$t"' EXIT
mkdir "$t/bin" "$t/state" "$t/dns"
export TEST_DIR="$t"
sed -e "s|/usr/libexec/|$t/bin/|g" -e "s|/usr/bin/xray|$t/bin/xray|g" \
    -e "s|/etc/init.d/|$t/bin/|g" -e "s|/var/etc/mango|$t/state|g" \
    -e "s|/etc/config/mango_proxy|$t/config|g" "$root/etc/init.d/mango_proxy" > "$t/init"
sed -e "s|/usr/libexec/|$t/bin/|g" -e "s|/var/etc/mango|$t/state|g" \
    "$root/usr/libexec/mango-dns" > "$t/bin/mango-dns"
cat > "$t/bin/mock" <<'EOF'
#!/bin/sh
n=${0##*/}
echo "$n $*" >> "$TEST_DIR/events"
case "$n" in
    uci)
        case "$*" in
            *main.mode) echo "$MODE";;
            *main.node) echo primary;;
            *main.failover) echo 0;;
        esac;;
    mango-dns-dir) echo "$TEST_DIR/dns";;
    mango-dns-config) echo "# policy $MODE";;
    dnsmasq)
        [ "${FAIL:-}" != dns-check ] || exit 1;;
    mango-generate)
        if [ "$1" = configure ]; then
            [ "${FAIL:-}" != configure ] || exit 1
        else echo '{}'; fi;;
    xray)
        [ "${FAIL:-}" != xray ] || exit 1
        [ "${FAIL:-}" != changed ] || echo changed >> "$TEST_DIR/config";;
    mango-fw) [ "${FAIL:-}" != firewall ] || exit 1;;
    mango-dns-ready) [ "${FAIL:-}" != dns-ready ] || exit 1;;
    mango-ready) exit 0;;
    mango-process) [ "$1" != wait ] || [ "${FAIL:-}" != old-exit ] || exit 1;;
esac
exit 0
EOF
chmod +x "$t/bin/mock" "$t/bin/mango-dns"
for name in uci mango-dns-dir mango-dns-config dnsmasq mango-assets mango-generate xray mango-fw mango-ready mango-dns-ready mango-cache mango-node-log mango-process firewall; do
    ln -s mock "$t/bin/$name"
done
export PATH="$t/bin:$PATH"
cat > "$t/run" <<'EOF'
#!/bin/sh
. "$TEST_DIR/init"
procd_open_instance() { echo new-instance >> "$TEST_DIR/events"; }
procd_set_param() { :; }
procd_close_instance() { :; }
stop() { stop_service; }
start() { start_service && service_started; }
reload_service
result=$?
[ "$mango_fw_applied" = 0 ] && [ "$mango_dns_applied" = 0 ] || exit 97
exit "$result"
EOF
reset_fixture() {
    rm -f "$t/state/active-node" "$t/state/config.tested" "$t/state/runtime-uncertain" "$t/state/reload-dhcp"
    echo original > "$t/config"
    echo working > "$t/state/active-node"
    echo old-runtime > "$t/state/runtime-state"
    : > "$t/events"
}
for MODE in direct split gfw global; do
    export MODE
    reset_fixture
    sh "$t/run"
    [ "$(grep -c '^mango-fw ' "$t/events")" = 1 ]
    [ "$(grep -c '^mango-dns-config ' "$t/events")" = 1 ]
    [ "$(grep -c '^dnsmasq --test ' "$t/events")" = 1 ]
    [ ! -e "$t/state/runtime-uncertain" ]
    grep -q '^total seconds=.* rc=0$' "$t/state/apply-timing"
    [ -z "$(find "$t/state" -name 'apply.*')" ]
    echo "PASS $MODE: single DNS validation/firewall load, ready state, cleanup"
done
MODE=split; export MODE
for FAIL in dns-check xray changed configure firewall dns-ready; do
    export FAIL
    reset_fixture
    if sh "$t/run"; then echo "FAIL accepted $FAIL"; exit 1; fi
    [ "$(cat "$t/state/runtime-state")" = old-runtime ]
    case "$FAIL" in
        dns-check|xray|changed)
            [ "$(cat "$t/state/active-node")" = working ]
            [ ! -e "$t/state/runtime-uncertain" ]
            ! grep -q '^mango-fw ' "$t/events"
            [ ! -e "$t/state/reload-dhcp" ];;
    esac
    [ -z "$(find "$t/state" -name 'apply.*')" ]
    echo "PASS failure: $FAIL"
done
unset FAIL
# Standalone starts must not inherit an optimization flag or skip the guard.
reset_fixture
printf '. "$TEST_DIR/init"\nstop_service\nstop_service\n' > "$t/stop"
sh "$t/stop"
[ "$(grep -c '^mango-fw ' "$t/events")" = 2 ]
echo 'PASS standalone guard remains active'
