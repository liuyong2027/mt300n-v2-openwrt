local G = dofile('package/luci-app-mango-proxy/root/usr/lib/mango/gfw.lua')
local rows={'[AutoProxy 0.2.9]','! test','||google.com','@@||safe.google.com','/regexp/','||path.example.com/secret','||google.com'}
for i=1,100 do rows[#rows+1]='||domain'..i..'.com' end
local text,count,skipped=G.convert(table.concat(rows,'\n'))
assert(count==101 and skipped==2)
assert(text:find('+google.com\n',1,true))
assert(text:find('-safe.google.com\n',1,true))
assert(not text:find('path.example',1,true))
assert(not pcall(G.convert,'<html>Error</html>'))
os.execute('mkdir -p reports')
G.write_dat('reports/gfw-test.dat', {'domain:google.com'}, {'safe.google.com'})
local dat=assert(io.open('reports/gfw-test.dat','rb'))
local blob=dat:read('*a'); dat:close()
assert(blob:find('GFW',1,true) and blob:find('google.com',1,true) and blob:find('DIRECT',1,true) and blob:find('safe.google.com',1,true))
local M=dofile('package/luci-app-mango-proxy/root/usr/lib/mango/model.lua')
local n={address='node.example.com',port='443',sni='www.example.com',uuid='00000000-0000-4000-8000-000000000001',public_key='CQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',short_id='0123456789abcdef',fingerprint='chrome'}
local proxy={}; for i=1,100 do proxy[#proxy+1]='domain:test'..i..'.example' end
G.write_dat('reports/gfw.dat',proxy,{'domain:safe.example'})
local cfg=M.xray({mode='gfw',gfw_proxy={'ext:gfw.dat:gfw'},gfw_direct={'ext:gfw.dat:direct'}},n)
local f=assert(io.open('reports/test-gfw-external.json','w')); f:write(M.json(cfg)); f:close()
print('GFW converter tests passed: exceptions, deduplication, unsupported rules, invalid input')
