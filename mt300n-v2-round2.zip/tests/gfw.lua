local G = dofile('package/luci-app-mango-proxy/root/usr/lib/mango/gfw.lua')
local rows={'[AutoProxy 0.2.9]','! test','||google.com','@@||safe.google.com','/regexp/','||path.example.com/secret','||google.com'}
for i=1,100 do rows[#rows+1]='||domain'..i..'.com' end
local text,count,skipped=G.convert(table.concat(rows,'\n'))
assert(count==101 and skipped==2)
assert(text:find('+google.com\n',1,true))
assert(text:find('-safe.google.com\n',1,true))
assert(not text:find('path.example',1,true))
assert(not pcall(G.convert,'<html>Error</html>'))
print('GFW converter tests passed: exceptions, deduplication, unsupported rules, invalid input')
