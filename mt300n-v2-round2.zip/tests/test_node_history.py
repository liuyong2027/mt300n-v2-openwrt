import os
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
@unittest.skipIf(os.name == 'nt', 'Requires Linux shell and flock')
class NodeHistoryTests(unittest.TestCase):
    def test_bounded_history_sanitizes_labels_and_keeps_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            uci=d/'uci'
            uci.write_text('#!/bin/sh\nprintf "node name\\nfake entry\\n"\n')
            uci.chmod(0o755)
            src=(ROOT/'package/luci-app-mango-proxy/root/usr/libexec/mango-node-log').read_text()
            src=src.replace('/var/etc/mango',str(d/'state')).replace('/var/lock',str(d/'locks'))
            script=d/'log'; script.write_text(src)
            env={**os.environ,'PATH':str(d)+':'+os.environ['PATH']}
            for i in range(55):
                subprocess.run(['sh',str(script),'manual','node1','node2',str(i)],env=env,check=True)
            rows=(d/'state/node-history').read_text().splitlines()
            self.assertEqual(len(rows),10)
            self.assertTrue(rows[0].endswith('| 45'))
            self.assertTrue(rows[-1].endswith('| 54'))
            self.assertIn('node name fake entry',rows[-1])
class ScriptEncodingTests(unittest.TestCase):
    def test_executable_scripts_use_linux_line_endings(self):
        for p in (ROOT/'package/luci-app-mango-proxy/root').rglob('*'):
            if p.is_file() and p.read_bytes().startswith(b'#!'):
                self.assertNotIn(b'\r',p.read_bytes(),str(p))

if __name__ == '__main__': unittest.main()
