const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../package/luci-app-mango-proxy/htdocs/luci-static/resources/view/mango-proxy.js'), 'utf8');
let map;
let pingCalls = [];
function element(tag, attrs, content) {
  return {tag, textContent: typeof content === 'string' ? content : '', children: content,
    addEventListener(event, fn) { this[event] = fn; }};
}
class Option {
  constructor(section, option) { this.section = section; this.option = option; this.current = undefined; }
  value(key, label) { (this.keylist ||= []).push(key); (this.vallist ||= []).push(label || key); }
  depends() {}
  formvalue() { return this.current; }
}
class Section {
  constructor() { this.children = []; }
  option(type, name) { const o = new Option(this, name); this.children.push(o); return o; }
}
class Map {
  constructor() { this.sections = []; map = this; }
  section() { const s = new Section(); this.sections.push(s); return s; }
  render() {
    // LuCI invokes validation after all sections have been constructed.
    const policy = this.sections[0];
    const mode = policy.children.find(o => o.option === 'mode');
    const node = policy.children.find(o => o.option === 'node');
    for (const value of ['direct', 'split', 'global', 'gfw']) {
      mode.current = value;
      assert.equal(node.validate('main', ''), value === 'direct' ? true : '代理模式必须选择节点');
      assert.equal(node.validate('main', 'node1'), true);
    }
    const backup = policy.children.find(o => o.option === 'backup_nodes');
    // Match Dropdown's Object.keys call, including empty and populated choices.
    assert.deepEqual(Object.keys(backup.transformChoices()), []);
    backup.value('node1', 'Primary');
    backup.value('node2', 'Backup');
    assert.deepEqual(Object.keys(backup.transformChoices()), ['node1', 'node2']);
    assert.equal(backup.transformChoices().node2, 'Backup');
    return Promise.resolve(null);
  }
}
const page = vm.runInNewContext('(function(){' + source + '\n})()', {
  view: { extend: v => v },
  rpc: { declare: spec => async id => { if (spec.method === 'ping') { pingCalls.push(id); return {exit_code:0,result:'12.0 ms'}; } return {}; } },
  E: element,
  form: { Map, NamedSection: Section, GridSection: Section, ListValue: Option, Value: Option, Flag: Option, DynamicList: Option, MultiValue: Option },
  uci: { load() {}, sections() {} }
});
page.tools = () => null;
page.render();
assert.equal(map.sections.length, 2);
console.log('UI regression passed: validation after node section creation, all four modes, empty and populated backup choices.');

const pingOption = map.sections[1].children.find(o => o.option === '_ping');
assert.equal(pingOption.editable, true, 'GridSection must render the Ping widget');
assert.equal(typeof pingOption.renderWidget, 'function');

(async () => {
  const first=pingOption.renderWidget('a'), second=pingOption.renderWidget('b');
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(pingCalls, [], 'opening page must not trigger probes');
  assert.equal(first.children[2].textContent, '检查');
  first.children[2].click();
  second.children[2].click();
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(pingCalls, ['a','b']);
  assert.equal(first.children[0].textContent, '12.0 ms');
  assert.equal(first.children[2].disabled, false);
  pingOption.renderWidget('a');
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(pingCalls.length, 2, 'rerender must not repeat automatic testing');
  second.children[2].click();
  second.children[2].click();
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(pingCalls.slice(2), ['b']);
  console.log('Ping UI passed: no automatic probes, manual single probe, serial queue, mean, rerender, double-click guard');
})().catch(e => {console.error(e);process.exitCode=1;});

const nodeSection=map.sections[1];
assert.equal(nodeSection.children[0].option, '_index');
nodeSection.cfgsections=()=>['nodeB','nodeA'];
const indexOption=nodeSection.children[0];
assert.equal(indexOption.cfgvalue('nodeB'),'1');
assert.equal(indexOption.cfgvalue('nodeA'),'2');
nodeSection.cfgsections=()=>['nodeA'];
assert.equal(indexOption.cfgvalue('nodeA'),'1');
console.log('Node numbering follows section order and deletion');
