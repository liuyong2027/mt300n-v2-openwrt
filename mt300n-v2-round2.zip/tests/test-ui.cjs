const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../package/luci-app-mango-proxy/htdocs/luci-static/resources/view/mango-proxy.js'), 'utf8');
let map;
class Option {
  constructor(section, option) { this.section = section; this.option = option; this.current = undefined; }
  value() {}
  depends() {}
  formvalue() { return this.current; }
}
class Section {
  constructor() { this.children = []; }
  option(type, name) { const o = new Option(this, name); this.children.push(o); return o; }
}
class Map {
  constructor() { this.sections = []; map = this; }
  section() { const s = new Section(); this.sections.push(s); return s; }
  render() {
    // LuCI invokes validation after all sections have been constructed.
    const policy = this.sections[0];
    const mode = policy.children.find(o => o.option === 'mode');
    const node = policy.children.find(o => o.option === 'node');
    for (const value of ['direct', 'split', 'global', 'gfw']) {
      mode.current = value;
      assert.equal(node.validate('main', ''), value === 'direct' ? true : '代理模式必须选择节点');
      assert.equal(node.validate('main', 'node1'), true);
    }
    return Promise.resolve(null);
  }
}
const page = vm.runInNewContext('(function(){' + source + '\n})()', {
  view: { extend: v => v },
  rpc: { declare: () => () => Promise.resolve({}) },
  E: () => null,
  form: { Map, NamedSection: Section, GridSection: Section, ListValue: Option, Value: Option, Flag: Option, DynamicList: Option },
  uci: { load() {}, sections() {} }
});
page.tools = () => null;
page.render();
assert.equal(map.sections.length, 2);
console.log('UI regression passed: validation after node section creation, all four modes.');
