#!/bin/sh
set -eu
root=${1:-.}/package/luci-app-mango-proxy/root
t=$(mktemp -d /tmp/mango-cache-test.XXXXXX)
trap 'rm -rf "$t"' EXIT
mkdir -p "$t/state" "$t/run" "$t/proc" "$t/bin"
export TEST_DIR="$t"
sed -e "s|/var/etc/mango|$t/state|g" -e "s|/var/run/dnsmasq|$t/run|g" -e "s|/proc/|$t/proc/|g" -e 's/kill -HUP /mock_signal /g' "$root/usr/libexec/mango-cache" > "$t/cache"
cat > "$t/bin/uci" <<'EOF'
#!/bin/sh
printf 'split\n'
EOF
cat > "$t/bin/mock_signal" <<'EOF'
#!/bin/sh
printf '%s\n' "$1" >> "$TEST_DIR/calls"
[ "$1" != "${FAIL_PID:-}" ]
EOF
chmod +x "$t/bin/"*
export PATH="$t/bin:$PATH"
reset_case() {
    rm -f "$t/state/"* "$t/run/"*
    : > "$t/calls"
    unset FAIL_PID
}
instance() {
    printf '%s\n' "$1" > "$t/run/$1.pid"
    mkdir -p "$t/proc/$1"
    printf '%s\n' "$2" > "$t/proc/$1/comm"
}
reject() {
    if sh "$t/cache"; then echo 'unexpected success'; exit 1; fi
    [ ! -e "$t/state/dns-policy.key" ]
}
reset_case
reject
echo 'PASS no instance does not publish key'
reset_case
instance 111 dnsmasq
sh "$t/cache"
[ "$(cat "$t/calls")" = 111 ]
[ -s "$t/state/dns-policy.key" ]
sh "$t/cache"
[ "$(wc -l < "$t/calls")" = 1 ]
echo 'PASS leader signalled; unchanged policy skipped'
reset_case
instance 111 dnsmasq
instance 222 dnsmasq
sh "$t/cache"
[ "$(wc -l < "$t/calls")" = 2 ]
echo 'PASS multiple instances'
reset_case
instance 333 unrelated
reject
[ ! -s "$t/calls" ]
echo 'PASS reused PID rejected'
reset_case
printf '999\n' > "$t/run/stale.pid"
reject
echo 'PASS missing process rejected'
reset_case
printf 'bad\n' > "$t/run/bad.pid"
reject
[ ! -s "$t/calls" ]
echo 'PASS invalid PID rejected'
reset_case
instance 111 dnsmasq
instance 222 dnsmasq
export FAIL_PID=222
reject
[ "$(wc -l < "$t/calls")" = 2 ]
echo 'PASS partial signal failure does not publish key'
