-- Mock only OpenWrt I/O; execute the real configuration generator.
local original_dofile, original_open, original_popen, original_write = dofile, io.open, io.popen, io.write
local state, pending, commits, main
local function reset()
    main={mode='split',node='one'}
    state={dhcp={dns={noresolv='1',server={'127.0.0.1#1053'},filter_aaaa='1'}},
        firewall={defaults={flow_offloading='0',flow_offloading_hw='0'},
            mango_zt_wan={enabled='0'},mango_zt_dns={enabled='0'}}}
    pending,commits={},{}
end
local cursor={}
function cursor:get_all() return main end
function cursor:get(c,s,k)
    if c=='mango_proxy' then return 'node' end
    return state[c][s][k]
end
function cursor:set(c,s,k,v) state[c][s][k]=v; return true end
function cursor:delete(c,s,k) state[c][s][k]=nil; return true end
function cursor:foreach(c,t,fn) fn({['.name']=c=='dhcp' and 'dns' or 'defaults'}) end
function cursor:commit(c)
    assert(pending['/var/etc/mango/reload-'..c], 'Must journal before commit')
    commits[#commits+1]=c
    return true
end
package.preload.uci=function() return {cursor=function() return cursor end} end
_G.dofile=function(path)
    if path:match('/model.lua$') then return {policy=function(p) return {mode=p.mode,sources=p.sources or {}} end} end
    if path:match('/failover.lua$') then return {active=function(p) return p.node end} end
    if path:match('/gfw.lua$') then return {load=function() error('configure must not parse GFW lists') end} end
    error(path)
end
io.open=function(path,mode)
    if mode=='w' then
        pending[path]=true
        return {write=function() return true end,close=function() return true end}
    end
    return nil
end
io.popen=function() return nil end
io.write=function() end
local function run()
    arg={'configure'}
    original_dofile('package/luci-app-mango-proxy/root/usr/libexec/mango-generate')
end
reset(); run(); assert(#commits==0)
main.node='two'; run(); assert(#commits==0,'Node switches must not restart DNS/firewall')
main.mode='gfw'; run(); assert(#commits==0)
main.mode='direct'; run(); assert(#commits==1 and commits[1]=='dhcp')
assert(state.dhcp.dns.server[1]=='223.5.5.5')
commits={}; run(); assert(#commits==0,'Repeated configure must be idempotent')
assert(pending['/var/etc/mango/reload-dhcp'],'Unacknowledged reload must remain pending')
reset(); main.sources={'10.1.2.0/24'}; run()
assert(#commits==1 and commits[1]=='firewall')
assert(state.firewall.mango_zt_wan.src_ip[1]=='10.1.2.0/24')
commits={}; main.sources={}; run()
assert(#commits==1 and commits[1]=='firewall')
assert(state.firewall.mango_zt_wan.src_ip==nil)
reset(); state.firewall.defaults.flow_offloading='1'; run()
assert(#commits==1 and commits[1]=='firewall')
_G.dofile,io.open,io.popen,io.write=original_dofile,original_open,original_popen,original_write
print('configure change detection and pending reload tests passed')
