import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('cn_rules', Path(__file__).parents[1] / 'scripts/cn_rules.py')
rules = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rules)

def record(code):
    inner = b'\x0a' + bytes([len(code)]) + code + b'\x12\x03abc'
    return b'\x0a' + bytes([len(inner)]) + inner

class RuleTests(unittest.TestCase):
    def test_domestic_dns_does_not_broaden_exact_or_regex_rules(self):
        def field(n,data): return bytes([n*8+2,len(data)])+data
        def domain(kind,name): return field(2,bytes([8,kind])+field(2,name))
        data=field(1,field(1,b'CN')+domain(2,b'baidu.com')+domain(3,b'www.example.org')+domain(1,b'.*cn'))
        names,skipped=rules.cn_domains(data)
        self.assertEqual(names,['baidu.com'])
        self.assertEqual(skipped,2)
    def test_only_requested_records_preserved(self):
        data = record(b'US') + record(b'CN') + record(b'PRIVATE')
        self.assertEqual(rules.trim(data, {'cn'}), record(b'CN'))
        self.assertEqual(rules.trim(data, {'cn', 'private'}), record(b'CN') + record(b'PRIVATE'))
    def test_missing_record_rejected(self):
        with self.assertRaises(ValueError): rules.trim(record(b'US'), {'cn'})
    def test_duplicate_record_rejected(self):
        with self.assertRaises(ValueError): rules.trim(record(b'CN') * 2, {'cn'})
    def test_truncated_record_rejected(self):
        with self.assertRaises(ValueError): rules.trim(record(b'CN')[:-1], {'cn'})
    def test_cn_cidr_extraction_ignores_other_countries(self):
        ip = bytes((1, 2, 3, 0))
        cidr = b'\x0a\x04' + ip + b'\x10\x18'
        inner = b'\x0a\x02cn\x12' + bytes([len(cidr)]) + cidr
        data = b'\x0a' + bytes([len(inner)]) + inner + record(b'US')
        self.assertEqual(rules.cn_cidrs(data), ['1.2.3.0/24'])

if __name__ == '__main__': unittest.main()
