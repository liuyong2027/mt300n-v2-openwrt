import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('cn_rules', Path(__file__).parents[1] / 'scripts/cn_rules.py')
rules = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rules)

def record(code):
    inner = b'\x0a' + bytes([len(code)]) + code + b'\x12\x03abc'
    return b'\x0a' + bytes([len(inner)]) + inner

class RuleTests(unittest.TestCase):
    def test_only_requested_records_preserved(self):
        data = record(b'US') + record(b'CN') + record(b'PRIVATE')
        self.assertEqual(rules.trim(data, {'cn'}), record(b'CN'))
        self.assertEqual(rules.trim(data, {'cn', 'private'}), record(b'CN') + record(b'PRIVATE'))
    def test_missing_record_rejected(self):
        with self.assertRaises(ValueError): rules.trim(record(b'US'), {'cn'})
    def test_duplicate_record_rejected(self):
        with self.assertRaises(ValueError): rules.trim(record(b'CN') * 2, {'cn'})
    def test_truncated_record_rejected(self):
        with self.assertRaises(ValueError): rules.trim(record(b'CN')[:-1], {'cn'})

if __name__ == '__main__': unittest.main()
