#!/bin/sh
set -eu
root=${1:-.}/package/luci-app-mango-proxy/root
t=$(mktemp -d /tmp/mango-watchdog-test.XXXXXX)
trap 'rm -rf "$t"' EXIT
mkdir "$t/bin"
export TEST_DIR="$t"
sed -e "s|/usr/libexec/|$t/bin/|g" -e "s|/proc/uptime|$t/uptime|g" \
    "$root/usr/libexec/mango-watchdog" > "$t/watchdog"
cat > "$t/bin/mock" <<'EOF'
#!/bin/sh
round=$(cat "$TEST_DIR/round")
case "${0##*/}" in
    sleep)
        [ "$round" -lt "$ROUNDS" ] || exit 1
        round=$((round+1))
        echo "$round" > "$TEST_DIR/round"
        echo "$((round*60)).0 0.0" > "$TEST_DIR/uptime";;
    uci)
        case "$*" in
            *main.mode) [ "$SCENARIO" = direct ] && echo direct || echo global;;
            *main.failover) [ "$SCENARIO" = disabled ] && echo 0 || echo 1;;
        esac;;
    flock) [ "$SCENARIO" != locked ] || exit 1;;
    mango-ready)
        echo "ready $round" >> "$TEST_DIR/events"
        case "$SCENARIO" in
            delayed) [ "$round" -ge 2 ] || exit 1;;
            never) exit 1;;
            crash) [ "$round" = 1 ] || exit 1;;
        esac;;
    mango-probe)
        echo "probe $round" >> "$TEST_DIR/events"
        case "$SCENARIO" in never) exit 1;; crash) [ "$round" = 1 ] || exit 1;; esac;;
    mango-failover) echo "failover $round" >> "$TEST_DIR/events";;
    logger) :;;
esac
exit 0
EOF
chmod +x "$t/bin/mock"
for n in sleep uci flock mango-ready mango-probe mango-failover logger; do ln -s mock "$t/bin/$n"; done
export PATH="$t/bin:$PATH"
run() {
    SCENARIO=$1 ROUNDS=$2; export SCENARIO ROUNDS
    echo 0 > "$t/round"
    echo '0.0 0.0' > "$t/uptime"
    : > "$t/events"
    sh "$t/watchdog"
}
run delayed 4
! grep -q '^probe 1$' "$t/events"
[ "$(grep -c '^probe ' "$t/events")" = 3 ]
! grep -q '^failover ' "$t/events"
echo 'PASS startup not ready is skipped; probing starts on readiness'
run never 5
! grep -q '^probe [12]$' "$t/events"
[ "$(grep -c '^probe ' "$t/events")" = 3 ]
grep -q '^failover 5$' "$t/events"
echo 'PASS persistent startup failure still reaches recovery after bounded grace'
run crash 4
[ "$(grep -c '^ready ' "$t/events")" = 1 ]
grep -q '^failover 4$' "$t/events"
echo 'PASS later core failure is not hidden by startup grace'
for scenario in locked direct disabled; do
    run "$scenario" 4
    [ ! -s "$t/events" ]
    echo "PASS existing skip policy: $scenario"
done
