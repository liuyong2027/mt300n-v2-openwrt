#!/usr/bin/env bash
set -euo pipefail
mkdir -p reports
lua5.1 tests/policy.lua
for file in reports/test-*.nft; do
    sudo unshare --net sh -ec 'ip link set lo up; nft -c -f "$1"; nft -f "$1"; nft -f "$1"' sh "$file"
done
if [ "${1:-}" = mips ]; then
    roots=(openwrt/build_dir/target-*/root-ramips)
    test "${#roots[@]}" = 1
    root="$(realpath "${roots[0]}")"
    test -s "$root/usr/share/xray/geoip.dat"
    test -s "$root/usr/share/xray/geosite.dat"
    for file in reports/test-*.json; do
        XRAY_LOCATION_ASSET="$root/usr/share/xray" qemu-mipsel-static -L "$root" \
            "$root/usr/bin/xray" run -test -config "$file"
    done
fi
