"""Report a baseline build without distributing untested firmware."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'reports'
OUT.mkdir(exist_ok=True)
OW = ROOT / 'openwrt'
required = {'luci', 'xray-core', 'luci-app-mango-proxy', 'zerotier', 'luci-app-zerotier-mini', 'lua', 'libuci-lua', 'ip-full', 'curl', 'coreutils-base64', 'flock', 'mango-tcpcheck'}
include_rules = True

def inspect_image(image, limit, installed):
    size = image.stat().st_size
    missing = sorted(required - installed)
    return {'file': image.name, 'bytes': size,
            'sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
            'image_limit_bytes': limit,
            'remaining_before_limit_bytes': limit - size,
            'missing_packages': missing,
            # Reserve 1 MiB in this preliminary screen. This is not a measured overlay size.
            'preliminary_capacity_pass': size <= limit - 1024 * 1024 and not missing}

def main():
    device_file = OW / 'target/linux/ramips/image/mt76x8.mk'
    text = device_file.read_text() if device_file.exists() else ''
    block = re.search(r'define Device/glinet_gl-mt300n-v2\n(.*?)\nendef', text, re.S)
    size_match = re.search(r'IMAGE_SIZE\s*:=\s*(\d+)k', block.group(1)) if block else None
    limit = int(size_match.group(1)) * 1024 if size_match else None
    target = OW / 'bin/targets/ramips/mt76x8'
    manifests = list(target.glob('*glinet_gl-mt300n-v2*.manifest'))
    installed = set()
    for manifest in manifests:
        installed.update(line.split()[0] for line in manifest.read_text().splitlines() if line.strip())
        (OUT / manifest.name).write_bytes(manifest.read_bytes())
    images = list(target.glob('*glinet_gl-mt300n-v2*squashfs-sysupgrade.bin'))
    entries = [inspect_image(p, limit, installed) for p in images] if limit else []
    log = ROOT / 'build.log'
    log_text = log.read_text(errors='replace') if log.exists() else ''
    oversized = bool(re.search(r'(too big|too large|exceeds|oversized)', log_text, re.I))
    result = {
        'purpose': 'capacity and build probe only; NOT validated firmware',
        'rules_included': (OUT / 'rules.json').exists(),
        'rules_note': 'CN GeoSite and CN/private GeoIP included in luci-app-mango-proxy',
        'image_limit_bytes': limit,
        'images': entries,
        'oversize_message_in_log': oversized,
        'build_step_outcome': os.environ.get('BUILD_OUTCOME', 'unknown'),
        'ready_to_flash': False,
        'pending': ['on-device REALITY/Vision and Wi-Fi tests', 'measured overlay/RAM use',
                    'on-device mode switching, DNS and ZeroTier gateway verification'],
    }
    (OUT / 'capacity.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    lines = ['# MT300N-V2 容量预检', '',
             '**这是构建预检，不是已验证固件；全部云端检查通过后提供测试镜像，仍需实机验证。**', '',
             '规则库：' + ('已生成 CN GeoSite 和 CN/private GeoIP 精简数据' if result['rules_included'] else '尚未成功生成规则数据'),
             f'构建步骤状态：{result["build_step_outcome"]}',
             f'设备 IMAGE_SIZE 上限：{limit} bytes', '']
    if not entries:
        lines.append('没有生成目标镜像。需要查看日志，区分容量超限和其他构建失败。')
    for e in entries:
        lines += [f'- 镜像：{e["file"]}', f'- 大小：{e["bytes"] / 1024 / 1024:.2f} MiB',
                  f'- 距分区上限：{e["remaining_before_limit_bytes"] / 1024:.0f} KiB（不是实测可写空间）',
                  f'- 缺失软件包：{e["missing_packages"]}',
                  f'- 预留 1 MiB 的初筛：{e["preliminary_capacity_pass"]}']
    lines += ['', '四模式、订阅、白名单、规则更新与节点守护已实现；增强功能待实机验证。']
    summary = '\n'.join(lines) + '\n'
    (OUT / 'SUMMARY.md').write_text(summary, encoding='utf-8')
    if os.environ.get('GITHUB_STEP_SUMMARY'):
        with open(os.environ['GITHUB_STEP_SUMMARY'], 'a', encoding='utf-8') as f:
            f.write(summary)
    print(summary)
    return 0 if (result['build_step_outcome'] == 'success' and entries
                 and all(e['preliminary_capacity_pass'] for e in entries)) else 1

if __name__ == '__main__':
    sys.exit(main())
