"""Keep CN (and private GeoIP) protobuf records; preserve original nested bytes."""
import hashlib
import json
from pathlib import Path
import urllib.request
import base64
import subprocess

SOURCES = {
    'geoip.dat': ('https://github.com/v2fly/geoip/releases/download/202609050329/geoip-only-cn-private.dat',
                  'bc7297903da14f6d725caafbf903e5a90026b9368f3d9f9ddbc7fd6f6dd1f1b0', {'cn', 'private'}),
    'geosite.dat': ('https://github.com/v2fly/domain-list-community/releases/download/20260914091725/dlc.dat',
                    '4f4df95fee39f8824449f271d773b28eb1f4471aa733d01750209df0dc373091', {'cn'}),
}

def varint(data, pos):
    n = 0
    for shift in range(0, 70, 7):
        if pos >= len(data):
            raise ValueError('Truncated varint')
        b = data[pos]
        pos += 1
        n |= (b & 127) << shift
        if not b & 128:
            return n, pos
    raise ValueError('Oversized varint')

def fields(data):
    pos = 0
    while pos < len(data):
        start = pos
        tag, pos = varint(data, pos)
        wire = tag & 7
        if wire == 2:
            size, pos = varint(data, pos)
            value = data[pos:pos + size]
            pos += size
        elif wire == 0:
            value, pos = varint(data, pos)
        elif wire in (1, 5):
            size = 8 if wire == 1 else 4
            value = data[pos:pos + size]
            pos += size
        else:
            raise ValueError('Unsupported wire type')
        if tag >> 3 == 0 or pos > len(data):
            raise ValueError('Malformed protobuf')
        yield tag >> 3, wire, value, data[start:pos]

def trim(data, keep):
    output = bytearray()
    found = set()
    for num, wire, record, raw in fields(data):
        if (num, wire) != (1, 2):
            raise ValueError('Unexpected top-level field')
        codes = [v.decode('ascii').lower() for n, w, v, _ in fields(record) if (n, w) == (1, 2)]
        if len(codes) != 1:
            raise ValueError('Missing or duplicate country code')
        if codes[0] in keep:
            if codes[0] in found:
                raise ValueError('Duplicate country record')
            found.add(codes[0])
            output.extend(raw)
    if found != keep:
        raise ValueError(f'Missing expected records: {keep - found}')
    return bytes(output)

def main():
    root = Path(__file__).resolve().parents[1]
    dest = root / 'package/luci-app-mango-proxy/root/usr/share/xray'
    dest.mkdir(parents=True, exist_ok=True)
    report = {}
    for name, (url, sha, keep) in SOURCES.items():
        print(f'Downloading {name}: {url}', flush=True)
        with urllib.request.urlopen(url, timeout=120) as response:
            raw = response.read()
        if hashlib.sha256(raw).hexdigest() != sha:
            raise ValueError(f'Hash mismatch: {name}')
        data = trim(raw, keep)
        (dest / name).write_bytes(data)
        report[name] = {'url': url, 'upstream_sha256': sha, 'records': sorted(keep),
                        'original_bytes': len(raw), 'trimmed_bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()}
    gfw_url = 'https://raw.githubusercontent.com/gfwlist/gfwlist/8ee49da41ae6f3a4f0f143053535a0f56fb00b8e/gfwlist.txt'
    with urllib.request.urlopen(gfw_url, timeout=120) as response:
        gfw = base64.b64decode(response.read())
    converted = subprocess.run(['lua5.1', '-e', "local m=dofile('package/luci-app-mango-proxy/root/usr/lib/mango/gfw.lua'); local data,n,s=m.convert(io.read('*a')); io.write(data); io.stderr:write('GFW domains: '..n..', skipped: '..s..'\\n')"],
                               input=gfw, stdout=subprocess.PIPE, check=True, cwd=root).stdout
    (dest / 'gfw-domains.txt').write_bytes(converted)
    report['gfw-domains.txt'] = {'url':gfw_url, 'bytes':len(converted), 'sha256':hashlib.sha256(converted).hexdigest(), 'license':'LGPL-2.1-or-later; https://github.com/gfwlist/gfwlist'}
    (root / 'reports/rules.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
