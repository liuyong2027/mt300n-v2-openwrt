"""Keep CN (and private GeoIP) protobuf records; preserve original nested bytes."""
import re
import hashlib
import json
from pathlib import Path
import urllib.request
import base64
import subprocess

SOURCES = {
    'geoip.dat': ('https://github.com/v2fly/geoip/releases/download/202609050329/geoip-only-cn-private.dat',
                  'bc7297903da14f6d725caafbf903e5a90026b9368f3d9f9ddbc7fd6f6dd1f1b0', {'cn', 'private'}),
    'geosite.dat': ('https://github.com/v2fly/domain-list-community/releases/download/20260914091725/dlc.dat',
                    '4f4df95fee39f8824449f271d773b28eb1f4471aa733d01750209df0dc373091', {'cn'}),
}

def varint(data, pos):
    n = 0
    for shift in range(0, 70, 7):
        if pos >= len(data):
            raise ValueError('Truncated varint')
        b = data[pos]
        pos += 1
        n |= (b & 127) << shift
        if not b & 128:
            return n, pos
    raise ValueError('Oversized varint')

def fields(data):
    pos = 0
    while pos < len(data):
        start = pos
        tag, pos = varint(data, pos)
        wire = tag & 7
        if wire == 2:
            size, pos = varint(data, pos)
            value = data[pos:pos + size]
            pos += size
        elif wire == 0:
            value, pos = varint(data, pos)
        elif wire in (1, 5):
            size = 8 if wire == 1 else 4
            value = data[pos:pos + size]
            pos += size
        else:
            raise ValueError('Unsupported wire type')
        if tag >> 3 == 0 or pos > len(data):
            raise ValueError('Malformed protobuf')
        yield tag >> 3, wire, value, data[start:pos]

def trim(data, keep):
    output = bytearray()
    found = set()
    for num, wire, record, raw in fields(data):
        if (num, wire) != (1, 2):
            raise ValueError('Unexpected top-level field')
        codes = [v.decode('ascii').lower() for n, w, v, _ in fields(record) if (n, w) == (1, 2)]
        if len(codes) != 1:
            raise ValueError('Missing or duplicate country code')
        if codes[0] in keep:
            if codes[0] in found:
                raise ValueError('Duplicate country record')
            found.add(codes[0])
            output.extend(raw)
    if found != keep:
        raise ValueError(f'Missing expected records: {keep - found}')
    return bytes(output)

def cn_cidrs(data):
    found = []
    for num, wire, record, _ in fields(data):
        if (num, wire) != (1, 2):
            raise ValueError('Unexpected top-level field')
        code = None
        for n, w, value, _ in fields(record):
            if (n, w) == (1, 2):
                code = value.decode('ascii').lower()
            elif (n, w) == (2, 2) and code == 'cn':
                ip = prefix = None
                try:
                    parts = list(fields(value))
                except ValueError:
                    continue
                for cn, cw, cv, _ in parts:
                    if (cn, cw) == (1, 2):
                        ip = cv
                    elif (cn, cw) == (2, 0):
                        prefix = cv
                if not ip or len(ip) != 4 or prefix is None or not 1 <= prefix <= 32:
                    continue
                found.append('.'.join(str(byte) for byte in ip) + f'/{prefix}')
    return found

def cn_domains(data):
    # Only root-domain records are exactly representable by dnsmasq suffix rules.
    # Full-name, keyword and regex records remain on the Xray DNS path.
    domains = set()
    skipped = 0
    for num, wire, record, _ in fields(data):
        parts = list(fields(record))
        if not any(n == 1 and w == 2 and v.lower() == b'cn' for n,w,v,_ in parts):
            continue
        for n,w,value,_ in parts:
            if (n,w) != (2,2):
                continue
            entry = list(fields(value))
            kind = next((v for n,w,v,_ in entry if (n,w)==(1,0)), 0)
            name = next((v.decode('ascii').lower() for n,w,v,_ in entry if (n,w)==(2,2)), '')
            if kind == 2 and len(name) <= 253 and all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label) for label in name.split('.')):
                domains.add(name)
            else:
                skipped += 1
    if not domains:
        raise ValueError('No representable CN domain rules')
    return sorted(domains), skipped

def main():
    root = Path(__file__).resolve().parents[1]
    dest = root / 'package/luci-app-mango-proxy/root/usr/share/xray'
    dest.mkdir(parents=True, exist_ok=True)
    report = {}
    for name, (url, sha, keep) in SOURCES.items():
        print(f'Downloading {name}: {url}', flush=True)
        with urllib.request.urlopen(url, timeout=120) as response:
            raw = response.read()
        if hashlib.sha256(raw).hexdigest() != sha:
            raise ValueError(f'Hash mismatch: {name}')
        data = trim(raw, keep)
        (dest / name).write_bytes(data)
        if name == 'geoip.dat':
            cidrs = cn_cidrs(data)
            (dest / 'cn-cidrs.txt').write_text(('\n'.join(cidrs) + '\n') if cidrs else '')
            report['cn-cidrs.txt'] = {'records': len(cidrs)}
        if name == 'geosite.dat':
            domains, skipped = cn_domains(data)
            (dest / 'cn-domains.txt').write_text('\n'.join(domains) + '\n')
            report['cn-domains.txt'] = {'records': len(domains), 'kept_on_xray': skipped}
        report[name] = {'url': url, 'upstream_sha256': sha, 'records': sorted(keep),
                        'original_bytes': len(raw), 'trimmed_bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()}
    gfw_url = 'https://raw.githubusercontent.com/gfwlist/gfwlist/8ee49da41ae6f3a4f0f143053535a0f56fb00b8e/gfwlist.txt'
    with urllib.request.urlopen(gfw_url, timeout=120) as response:
        gfw = base64.b64decode(response.read())
    converted = subprocess.run(['lua5.1', '-e', "local m=dofile('package/luci-app-mango-proxy/root/usr/lib/mango/gfw.lua'); local data,n,s=m.convert(io.read('*a')); io.write(data); io.stderr:write('GFW domains: '..n..', skipped: '..s..'\\n')"],
                               input=gfw, stdout=subprocess.PIPE, check=True, cwd=root).stdout
    (dest / 'gfw-domains.txt').write_bytes(converted)
    report['gfw-domains.txt'] = {'url':gfw_url, 'bytes':len(converted), 'sha256':hashlib.sha256(converted).hexdigest(), 'license':'LGPL-2.1-or-later; https://github.com/gfwlist/gfwlist'}
    (root / 'reports/rules.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
