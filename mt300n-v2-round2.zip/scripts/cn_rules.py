"""Keep CN (and private GeoIP) protobuf records; preserve original nested bytes."""
import hashlib
import json
from pathlib import Path
import urllib.request

SOURCES = {
    'geoip.dat': ('https://github.com/v2fly/geoip/releases/download/202605120112/geoip.dat',
                  'e9002979e0df72bce1c8751ff70725386594c551db684b7a232935b8b2bb8aa2', {'cn', 'private'}),
    'geosite.dat': ('https://github.com/v2fly/domain-list-community/releases/download/20260518025449/dlc.dat',
                    '330e9383df4b232747d900c70ff1718d396e0fff4914930285c24657e7f013a1', {'cn'}),
}

def varint(data, pos):
    n = 0
    for shift in range(0, 70, 7):
        if pos >= len(data):
            raise ValueError('Truncated varint')
        b = data[pos]
        pos += 1
        n |= (b & 127) << shift
        if not b & 128:
            return n, pos
    raise ValueError('Oversized varint')

def fields(data):
    pos = 0
    while pos < len(data):
        start = pos
        tag, pos = varint(data, pos)
        wire = tag & 7
        if wire == 2:
            size, pos = varint(data, pos)
            value = data[pos:pos + size]
            pos += size
        elif wire == 0:
            value, pos = varint(data, pos)
        elif wire in (1, 5):
            size = 8 if wire == 1 else 4
            value = data[pos:pos + size]
            pos += size
        else:
            raise ValueError('Unsupported wire type')
        if tag >> 3 == 0 or pos > len(data):
            raise ValueError('Malformed protobuf')
        yield tag >> 3, wire, value, data[start:pos]

def trim(data, keep):
    output = bytearray()
    found = set()
    for num, wire, record, raw in fields(data):
        if (num, wire) != (1, 2):
            raise ValueError('Unexpected top-level field')
        codes = [v.decode('ascii').lower() for n, w, v, _ in fields(record) if (n, w) == (1, 2)]
        if len(codes) != 1:
            raise ValueError('Missing or duplicate country code')
        if codes[0] in keep:
            if codes[0] in found:
                raise ValueError('Duplicate country record')
            found.add(codes[0])
            output.extend(raw)
    if found != keep:
        raise ValueError(f'Missing expected records: {keep - found}')
    return bytes(output)

def main():
    root = Path(__file__).resolve().parents[1]
    dest = root / 'package/luci-app-mango-proxy/root/usr/share/xray'
    dest.mkdir(parents=True, exist_ok=True)
    report = {}
    for name, (url, sha, keep) in SOURCES.items():
        with urllib.request.urlopen(url, timeout=120) as response:
            raw = response.read()
        if hashlib.sha256(raw).hexdigest() != sha:
            raise ValueError(f'Hash mismatch: {name}')
        data = trim(raw, keep)
        (dest / name).write_bytes(data)
        report[name] = {'url': url, 'upstream_sha256': sha, 'records': sorted(keep),
                        'original_bytes': len(raw), 'trimmed_bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()}
    (root / 'reports/rules.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
