#!/usr/bin/env bash
set -euo pipefail
kit="$(cd "$(dirname "$0")/.." && pwd)"
cd "$kit"
mkdir -p reports
python3 scripts/cn_rules.py
test ! -e openwrt
git init openwrt
git -C openwrt remote add origin https://github.com/openwrt/openwrt.git
git -C openwrt fetch --depth 1 origin f0a60eee2fe051741c643ea6118718aae1ef17fb
git -C openwrt checkout --detach FETCH_HEAD
cd openwrt
test "$(git rev-parse HEAD)" = f0a60eee2fe051741c643ea6118718aae1ef17fb
# The release includes exact feed commits. Do not replace them with moving branches.
cp feeds.conf.default "$kit/reports/feeds.conf.lock"
./scripts/feeds update -a
./scripts/feeds install -a
cp -R "$kit/package/luci-app-zerotier-mini" package/
cp -R "$kit/package/luci-app-mango-proxy" package/
chmod +x package/luci-app-mango-proxy/root/usr/libexec/mango-* \
    package/luci-app-mango-proxy/root/etc/init.d/mango_proxy \
    package/luci-app-mango-proxy/root/etc/uci-defaults/95-mango-proxy
cp -R "$kit/files" .
cp "$kit/config/mt300n-v2.config" .config
make defconfig
for pkg in luci xray-core luci-app-mango-proxy zerotier luci-app-zerotier-mini lua libuci-lua ip-full; do
    grep -qx "CONFIG_PACKAGE_${pkg}=y" .config || {
        echo "Required package was dropped by Kconfig: $pkg" >&2
        exit 1
    }
done
grep -qx 'CONFIG_TARGET_ramips_mt76x8_DEVICE_glinet_gl-mt300n-v2=y' .config
! grep -qx 'CONFIG_PACKAGE_luci-app-xray=y' .config
! grep -qx 'CONFIG_PACKAGE_v2ray-geoip=y' .config
! grep -qx 'CONFIG_PACKAGE_v2ray-geosite=y' .config
cp .config "$kit/reports/resolved.config"
./scripts/diffconfig.sh > "$kit/reports/diffconfig.txt"
git rev-parse HEAD > "$kit/reports/openwrt-commit.txt"
find feeds -mindepth 1 -maxdepth 1 -type d | sort | while read -r feed; do
    printf '%s ' "$feed"
    git -C "$feed" rev-parse HEAD
done > "$kit/reports/feed-commits.txt"
