# ZeroTier 地址转换管理决定

按用户要求，撤销拟新增的 Xray 页面开关、目标列表和自动 NAT/hotplug 逻辑。
继续在网络 → 防火墙 → mangozt 区域配置 IPv4 动态伪装及源/目标限制。
路由器当前人工配置未修改。
此前 2026-09-25-zt-nat 源码包为已撤销方案，不作为下一版构建输入。

## 下一版固件默认值

按用户确认，在 uci-defaults/95-mango-proxy 中设置 mangozt 入站 ACCEPT、IPv4 动态伪装开启。
按最新要求，伪装源网段和目标网段均留空：初始化时删除 masq_src、masq_dest，不写入具体网段。
动态伪装不限制源/目标网段，作用于从 mangozt 区域接口发出的 IPv4 流量，仍受路由和转发规则控制。
出站 ACCEPT、转发 REJECT 和 lan → mangozt 转发保持原值；不增加 mangozt → lan 转发。
这些是下一版固件的初始化默认值，不自动调整 LAN 地址；更改 LAN 网段无需同步修改空的伪装源限制。
未对运行中的路由器执行修改或重启。未新增 Xray 页面管理入口。
